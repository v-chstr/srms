import defaultTheme from 'tailwindcss/defaultTheme';
import forms from '@tailwindcss/forms';

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './storage/framework/views/*.php',
        './resources/views/**/*.blade.php',
        './config/*.php',
    ],

    theme: {
        extend: {
            colors: {
                // Primary — deep scholarly purple (SPUP SITE department color)
                primary: {
                    50:  '#f4f2fd',
                    100: '#eae6fb',
                    200: '#d5ccf7',
                    300: '#b9abf0',
                    400: '#9780e7',
                    500: '#7b5bdb',
                    600: '#6445c4',
                    700: '#5236a8',
                    800: '#412b8a',
                    900: '#2e1e6d',
                },
                // Accent — warm academic gold
                accent: {
                    50:  '#fffbeb',
                    100: '#fef3c7',
                    200: '#fde68a',
                    300: '#fcd34d',
                    400: '#fbbf24',
                    500: '#f59e0b',
                    600: '#d97706',
                    700: '#b45309',
                },
                // Status — semantic surface tints (use as bg/text pairs, never raw Tailwind colors)
                // bg-status-*      → badge background tint
                // text-status-*-fg → badge foreground text on light tint
                'status-pending':  { DEFAULT: '#e0e7ff', fg: '#3730a3' }, // indigo-100 bg / indigo-800 text
                'status-revision': { DEFAULT: '#fef3c7', fg: '#92400e' }, // amber-100  bg / amber-800  text
                'status-approved': { DEFAULT: '#d1fae5', fg: '#065f46' }, // emerald-100 bg / emerald-800 text
            },
        },
    },

    plugins: [forms],
};
