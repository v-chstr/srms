<?php

use App\Http\Controllers\UserSearchController;
use App\Http\Controllers\Admin\CourseController;
use App\Http\Controllers\Admin\PaperController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Adviser\ReviewController;
use App\Http\Controllers\AnnouncementListController;
use App\Http\Controllers\AnnouncementManageController;
use App\Http\Controllers\ArchiveController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ScheduleController;
use App\Http\Controllers\Student\ResearchController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/login');

// Archive — public (auth-optional) research library
Route::get('/archive', [ArchiveController::class, 'index'])->name('archive.index');
Route::get('/archive/{id}', [ArchiveController::class, 'show'])->name('archive.show');
Route::get('/archive/{id}/download', [ArchiveController::class, 'download'])->name('archive.download');
Route::get('/archive/{id}/thumbnail', [ArchiveController::class, 'thumbnail'])->name('archive.thumbnail');

Route::middleware(['auth', 'verified', 'no-back'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
});

Route::middleware(['auth', 'no-back'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::patch('/profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Notifications
    Route::patch('/notifications/{id}/read', [NotificationController::class, 'read'])->name('notifications.read');
    Route::post('/notifications/read-all', [NotificationController::class, 'readAll'])->name('notifications.read-all');
    Route::delete('/notifications/{id}', [NotificationController::class, 'destroy'])->name('notifications.destroy');
    Route::delete('/notifications', [NotificationController::class, 'clearAll'])->name('notifications.clear-all');

    // Announcements — index is available to all authenticated users
    Route::get('/announcements', [AnnouncementListController::class, 'index'])->name('announcements.index');

    // User name search — for author-input autocomplete (suggestions only, not restrictive)
    Route::get('/users/search', [UserSearchController::class, 'search'])->name('users.search');

    // Schedule events — all authenticated users can view calendar events
    Route::get('/schedules/events', [ScheduleController::class, 'events'])->name('schedules.events');
});

// Schedule CRUD — restricted to admin + adviser
Route::middleware(['auth', 'role:admin,adviser', 'no-back'])->prefix('schedules')->name('schedules.')->group(function () {
    Route::post('/', [ScheduleController::class, 'store'])->name('store');
    Route::put('{schedule}', [ScheduleController::class, 'update'])->name('update');
    Route::delete('{schedule}', [ScheduleController::class, 'destroy'])->name('destroy');
});


// Student routes
Route::middleware(['auth', 'role:student', 'no-back'])->prefix('student')->name('student.')->group(function () {
    Route::get('research', [ResearchController::class, 'index'])->name('research.index');
    Route::post('research', [ResearchController::class, 'store'])->name('research.store');
    Route::put('research/{id}', [ResearchController::class, 'update'])->name('research.update');
    Route::get('research/{id}/download', [ResearchController::class, 'download'])->name('research.download');
});

// Adviser routes (any admin/staff user can advise)
Route::middleware(['auth', 'role:adviser', 'no-back'])->prefix('adviser')->name('adviser.')->group(function () {
    Route::get('reviews', [ReviewController::class, 'index'])->name('reviews.index');
    Route::post('reviews/{paper}', [ReviewController::class, 'store'])->name('reviews.store');
    Route::get('reviews/{paper}/download', [ReviewController::class, 'download'])->name('reviews.download');

    Route::get('announcements', [AnnouncementManageController::class, 'index'])->name('announcements.index');
    Route::post('announcements', [AnnouncementManageController::class, 'store'])->name('announcements.store');
    Route::put('announcements/{announcement}', [AnnouncementManageController::class, 'update'])->name('announcements.update');
    Route::delete('announcements/{announcement}', [AnnouncementManageController::class, 'destroy'])->name('announcements.destroy');
});

// Admin routes
Route::middleware(['auth', 'role:admin', 'no-back'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('users', [UserController::class, 'index'])->name('users.index');
    Route::post('users', [UserController::class, 'store'])->name('users.store');
    Route::put('users/{user}', [UserController::class, 'update'])->name('users.update');
    Route::post('users/{user}/approve', [UserController::class, 'approve'])->name('users.approve');
    Route::delete('users/{user}', [UserController::class, 'destroy'])->name('users.destroy');

    Route::get('courses', [CourseController::class, 'index'])->name('courses.index');
    Route::post('courses', [CourseController::class, 'store'])->name('courses.store');
    Route::put('courses/{course}', [CourseController::class, 'update'])->name('courses.update');

    Route::get('announcements', [AnnouncementManageController::class, 'index'])->name('announcements.index');
    Route::post('announcements', [AnnouncementManageController::class, 'store'])->name('announcements.store');
    Route::put('announcements/{announcement}', [AnnouncementManageController::class, 'update'])->name('announcements.update');
    Route::delete('announcements/{announcement}', [AnnouncementManageController::class, 'destroy'])->name('announcements.destroy');

    Route::get('papers', [PaperController::class, 'index'])->name('papers.index');
    Route::post('papers', [PaperController::class, 'store'])->name('papers.store');
    Route::get('papers/{paper}/download', [PaperController::class, 'download'])->name('papers.download');
    Route::delete('papers/{paper}', [PaperController::class, 'destroy'])->name('papers.destroy');
});

require __DIR__.'/auth.php';
