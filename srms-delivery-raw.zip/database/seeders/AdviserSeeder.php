<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdviserSeeder extends Seeder
{
    public function run(): void
    {
        $advisers = [
            [
                'email'      => 'pugeda.rucelj@gmail.com',
                'first_name' => 'Rucelj',
                'last_name'  => 'Pugeda',
                'status'     => 'active',
                'password'   => 'teacher1234',
            ],
            [
                'email'      => 'babaran.carlosjr@gmail.com',
                'first_name' => 'Carlos',
                'last_name'  => 'Babaran Jr.',
                'status'     => 'active',
                'password'   => 'teacher1234',
            ],
        ];

        foreach ($advisers as $adviser) {
            User::updateOrCreate(
                ['email' => $adviser['email']],
                [
                    'first_name' => $adviser['first_name'],
                    'last_name'  => $adviser['last_name'],
                    'password'   => Hash::make($adviser['password']),
                    'role'       => 'adviser',
                    'status'     => $adviser['status'],
                    'is_adviser' => false,
                    'course_id'  => null,
                ]
            );
        }
    }
}
