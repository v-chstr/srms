<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        $this->call([
            // 1. Reference data first
            CourseSeeder::class,

            // 2. Users — order matters: admins before advisers before students
            AdminSeeder::class,
            AdviserSeeder::class,
            StudentSeeder::class,

            // 3. Content that references users/courses
            AnnouncementSeeder::class,

            // 4. Defense schedules — only inserts if matching papers exist (manual upload required)
            //    Safe to run; guards against missing papers with null checks.
            DefenseScheduleSeeder::class,

            // ResearchPaperSeeder and ReviewSeeder are intentionally omitted.
            // Papers require real PDF uploads via the UI. Run manually after uploading.
        ]);
    }
}
