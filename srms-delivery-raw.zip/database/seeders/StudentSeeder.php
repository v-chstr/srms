<?php

namespace Database\Seeders;

use App\Models\Course;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class StudentSeeder extends Seeder
{
    public function run(): void
    {
        $it = Course::where('code', 'IT')->first();

        $students = [
            ['email' => 'fortes.jherilyn@gmail.com',  'first_name' => 'Jherilyn',   'last_name' => 'Fortes',  'course' => $it, 'status' => 'active'],
            ['email' => 'lopez.cyrenejoy@gmail.com',  'first_name' => 'Cyrene Joy', 'last_name' => 'Lopez',   'course' => $it, 'status' => 'active'],
        ];

        foreach ($students as $student) {
            User::updateOrCreate(
                ['email' => $student['email']],
                [
                    'first_name' => $student['first_name'],
                    'last_name'  => $student['last_name'],
                    'password'   => Hash::make('student1234'),
                    'role'       => 'student',
                    'status'     => $student['status'],
                    'is_adviser' => false,
                    'course_id'  => $student['course']?->id,
                ]
            );
        }
    }
}
