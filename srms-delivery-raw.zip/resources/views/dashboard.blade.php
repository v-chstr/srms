<x-layouts.app title="Dashboard">

    <div class="space-y-4">

        {{-- ── Announcement banner (all roles) ──────────────────── --}}
        @if($latestAnnouncement)
            <div class="rounded-lg border border-primary-200 overflow-hidden">
                <div class="bg-primary-900 px-4 sm:px-5 py-2.5 flex items-center gap-2.5">
                    <svg class="h-4 w-4 shrink-0 text-primary-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M10.34 15.84c-.688-.06-1.386-.09-2.09-.09H7.5a4.5 4.5 0 110-9h.75c.704 0 1.402-.03 2.09-.09m0 9.18c.253.962.584 1.892.985 2.783.247.55.06 1.21-.463 1.511l-.657.38c-.551.318-1.26.117-1.527-.461a20.845 20.845 0 01-1.44-4.282m3.102.069a18.03 18.03 0 01-.59-4.59c0-1.586.205-3.124.59-4.59m0 9.18a23.848 23.848 0 018.835 2.535M10.34 6.66a23.847 23.847 0 008.835-2.535m0 0A23.74 23.74 0 0018.795 3m.38 1.125a23.91 23.91 0 011.014 5.395m-1.014 8.855c-.118.38-.245.754-.38 1.125m.38-1.125a23.91 23.91 0 001.014-5.395m0-3.46c.495.413.811 1.035.811 1.73 0 .695-.316 1.317-.811 1.73m0-3.46a24.347 24.347 0 010 3.46"/>
                    </svg>
                    <span class="text-[12px] font-semibold text-white">Announcement</span>
                    @if($latestAnnouncement->course)
                        <span class="text-xs font-medium text-primary-200 bg-primary-800 px-2 py-0.5 rounded-md">{{ $latestAnnouncement->course->code }}</span>
                    @else
                        <span class="text-xs text-primary-400">All departments</span>
                    @endif
                    <span class="ml-auto text-xs text-primary-300">{{ $latestAnnouncement->created_at->diffForHumans() }}</span>
                </div>
                <div class="bg-white px-4 sm:px-5 py-3 sm:py-4">
                    <h3 class="text-sm font-semibold text-gray-900">{{ $latestAnnouncement->title }}</h3>
                    <p class="mt-0.5 text-xs text-gray-400">
                        Posted by {{ $latestAnnouncement->poster ? trim($latestAnnouncement->poster->first_name . ' ' . $latestAnnouncement->poster->last_name) : 'Unknown' }}
                    </p>
                    <p class="mt-1.5 text-sm text-gray-500 line-clamp-2">{{ $latestAnnouncement->message }}</p>
                </div>
                <div class="bg-gray-50 px-4 sm:px-5 py-2.5 border-t border-gray-100 flex items-center justify-between gap-3">
                    @php
                        $announcementsUrl = match(true) {
                            auth()->user()->isAdmin()   => route('admin.announcements.index'),
                            auth()->user()->canAdvise() => route('adviser.announcements.index'),
                            default                     => route('announcements.index'),
                        };
                    @endphp
                    <a href="{{ $announcementsUrl }}" data-nav-link class="text-[12px] font-medium text-primary-700 hover:text-primary-900">
                        See all announcements
                    </a>
                    @if($unseenAnnouncementCount > 0)
                        <span class="shrink-0 text-[11px] font-semibold bg-accent-100 text-accent-800 border border-accent-200 px-2 py-0.5 rounded-md tabular-nums">
                            {{ $unseenAnnouncementCount }} unread
                        </span>
                    @endif
                </div>
            </div>
        @endif

        {{-- ══════════════════════════════════════════════════════ --}}
        {{-- ── ADMIN DASHBOARD ───────────────────────────────── --}}
        {{-- ══════════════════════════════════════════════════════ --}}
        @if($role === 'admin')

            <x-ui.stats-grid :items="$statItems" />

            {{-- Defense Calendar --}}
            <x-ui.schedule-calendar :events="$scheduleEvents" :canCreate="true" />
            <x-ui.schedule-modal :courses="$courses" />
            @foreach($schedules as $s)
                <x-ui.schedule-modal :schedule="$s" :courses="$courses" />
            @endforeach

                {{-- Left column --}}
                <div class="lg:col-span-2 flex flex-col gap-4">

                    {{-- Recent Submissions --}}
                    <x-ui.card title="Recent Submissions" :compact="true"
                        :viewAllRoute="route('admin.papers.index')"
                        :empty="$recentPapers->isEmpty()"
                        emptyText="No research submissions yet.">
                        <x-table.wrapper class="border-0">
                            <x-slot:head>
                                <x-table.heading>Title</x-table.heading>
                                <x-table.heading class="hidden sm:table-cell">Student</x-table.heading>
                                <x-table.heading class="hidden sm:table-cell">Course</x-table.heading>
                                <x-table.heading>Status</x-table.heading>
                                <x-table.heading class="hidden lg:table-cell text-right">Date</x-table.heading>
                            </x-slot:head>
                            @foreach($recentPapers as $paper)
                                <tr>
                                    <x-table.cell class="max-w-[200px] truncate">{{ $paper->title }}</x-table.cell>
                                    <x-table.cell class="hidden sm:table-cell">{{ $paper->submitter?->first_name }} {{ $paper->submitter?->last_name }}</x-table.cell>
                                    <x-table.cell class="hidden sm:table-cell">{{ $paper->course?->code ?? 'N/A' }}</x-table.cell>
                                    <x-table.cell><x-ui.badge :status="$paper->status" /></x-table.cell>
                                    <x-table.cell class="hidden lg:table-cell text-right text-gray-400"><x-ui.date :value="$paper->created_at" short /></x-table.cell>
                                </tr>
                            @endforeach
                        </x-table.wrapper>
                    </x-ui.card>

                    {{-- Pending Accounts --}}
                    <x-ui.card title="Pending Account Requests" :compact="true"
                        :viewAllRoute="route('admin.users.index')"
                        maxHeight="max-h-56"
                        :empty="$pendingUsers->isEmpty()"
                        emptyText="No pending accounts.">
                        <div class="divide-y divide-gray-50">
                            @foreach($pendingUsers as $pUser)
                                <div class="flex items-center gap-3 px-4 py-2.5">
                                    <div class="flex h-7 w-7 shrink-0 items-center justify-center bg-gray-100 text-xs font-semibold text-gray-500">
                                        {{ strtoupper(substr($pUser->first_name, 0, 1)) }}{{ strtoupper(substr($pUser->last_name, 0, 1)) }}
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-800 truncate">{{ $pUser->first_name }} {{ $pUser->last_name }}</p>
                                        <p class="text-xs text-gray-400 truncate">
                                            {{ $pUser->email }}
                                            @if($pUser->course) / {{ $pUser->course->code }} @endif
                                        </p>
                                    </div>
                                    <span class="shrink-0 text-xs font-semibold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded-md">Pending</span>
                                </div>
                            @endforeach
                        </div>
                    </x-ui.card>

                </div>

                {{-- Right column: papers by program --}}
                <div class="lg:col-span-1">
                    @php $maxPapers = $courseOutput->max('count') ?: 1; @endphp
                    <x-ui.card title="Papers by Program" :compact="true"
                        :empty="$courseOutput->isEmpty()"
                        emptyText="No papers submitted yet.">
                        <div class="grid grid-cols-2 gap-px bg-gray-100">
                            @foreach($courseOutput as $course)
                                <div class="bg-white px-4 py-3">
                                    <div class="flex items-baseline justify-between mb-1.5">
                                        <span class="text-sm font-semibold text-gray-800">{{ $course['code'] }}</span>
                                        <span class="text-xs tabular-nums font-medium text-gray-400">{{ $course['count'] }}</span>
                                    </div>
                                    <div class="h-1 bg-gray-100 overflow-hidden">
                                        <div class="h-full bg-primary-500" style="width: {{ $course['count'] > 0 ? round(($course['count'] / $maxPapers) * 100) : 0 }}%"></div>
                                    </div>
                                    <p class="mt-1 text-xs text-gray-400 truncate">{{ $course['name'] }}</p>
                                </div>
                            @endforeach
                        </div>
                    </x-ui.card>
                </div>

            </div>

        {{-- ══════════════════════════════════════════════════════ --}}
        {{-- ── ADVISER DASHBOARD ─────────────────────────────── --}}
        {{-- ══════════════════════════════════════════════════════ --}}
        @elseif($role === 'adviser')

            <x-ui.stats-grid :items="$statItems" />

            {{-- Defense Calendar --}}
            <x-ui.schedule-calendar :events="$scheduleEvents" :canCreate="true" />
            <x-ui.schedule-modal :courses="$courses" />
            @foreach($schedules as $s)
                <x-ui.schedule-modal :schedule="$s" :courses="$courses" />
            @endforeach

            <x-ui.card title="Recent Submissions" :compact="true"
                :viewAllRoute="route('adviser.reviews.index')"
                :empty="$recentPapers->isEmpty()"
                emptyText="No papers assigned yet.">
                <x-table.wrapper class="border-0">
                    <x-slot:head>
                        <x-table.heading>Title</x-table.heading>
                        <x-table.heading class="hidden sm:table-cell">Student</x-table.heading>
                        <x-table.heading class="hidden sm:table-cell">Course</x-table.heading>
                        <x-table.heading>Status</x-table.heading>
                        <x-table.heading class="hidden lg:table-cell text-right">Date</x-table.heading>
                    </x-slot:head>
                    @foreach($recentPapers as $paper)
                        <tr>
                            <x-table.cell class="max-w-[200px] truncate">{{ $paper->title }}</x-table.cell>
                            <x-table.cell class="hidden sm:table-cell">{{ $paper->submitter?->first_name }} {{ $paper->submitter?->last_name }}</x-table.cell>
                            <x-table.cell class="hidden sm:table-cell">{{ $paper->course?->code ?? 'N/A' }}</x-table.cell>
                            <x-table.cell><x-ui.badge :status="$paper->status" /></x-table.cell>
                            <x-table.cell class="hidden lg:table-cell text-right text-gray-400"><x-ui.date :value="$paper->created_at" short /></x-table.cell>
                        </tr>
                    @endforeach
                </x-table.wrapper>
            </x-ui.card>

        {{-- ══════════════════════════════════════════════════════ --}}
        {{-- ── STUDENT DASHBOARD ─────────────────────────────── --}}
        {{-- ══════════════════════════════════════════════════════ --}}
        @elseif($role === 'student')

            <x-ui.stats-grid :items="$statItems" />

            {{-- Defense Calendar (read-only for students) --}}
            <x-ui.schedule-calendar :events="$scheduleEvents" :canCreate="false" />

            <x-ui.card title="My Submissions" :compact="true"
                :viewAllRoute="route('student.research.index')"
                :empty="$recentPapers->isEmpty()"
                emptyText="No research submissions yet.">
                <x-table.wrapper class="border-0">
                    <x-slot:head>
                        <x-table.heading>Title</x-table.heading>
                        <x-table.heading class="hidden sm:table-cell">Course</x-table.heading>
                        <x-table.heading>Status</x-table.heading>
                        <x-table.heading class="hidden lg:table-cell text-right">Date</x-table.heading>
                    </x-slot:head>
                    @foreach($recentPapers as $paper)
                        <tr>
                            <x-table.cell class="max-w-[200px] truncate">{{ $paper->title }}</x-table.cell>
                            <x-table.cell class="hidden sm:table-cell">{{ $paper->course?->code ?? 'N/A' }}</x-table.cell>
                            <x-table.cell><x-ui.badge :status="$paper->status" /></x-table.cell>
                            <x-table.cell class="hidden lg:table-cell text-right text-gray-400"><x-ui.date :value="$paper->created_at" short /></x-table.cell>
                        </tr>
                    @endforeach
                </x-table.wrapper>
            </x-ui.card>

        @endif

    </div>

</x-layouts.app>
