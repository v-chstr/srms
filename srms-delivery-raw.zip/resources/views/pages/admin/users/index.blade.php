﻿<x-layouts.app title="User Management">

    <x-layouts.page-header title="User Management" subtitle="View and manage system accounts" />

    @php
        $serializeUser = fn ($u) => [
            'id'            => $u->id,
            'first_name'    => $u->first_name,
            'last_name'     => $u->last_name,
            'email'         => $u->email,
            'role'          => $u->role,
            'original_role' => $u->role,
            'status'        => $u->status,
            'is_adviser'    => (bool) $u->is_adviser,
            'course_id'     => $u->course_id,
            'course_name'   => $u->course->name ?? 'N/A',
            'created_at'    => $u->created_at->srmsDate(),
        ];

        $allUsersJson = $users->map($serializeUser)->merge($pendingUsers->map($serializeUser));
    @endphp

    <div x-data="{
        allUsers: @js($allUsersJson),
        adviserPapersMap: @js($adviserPapersMap),
        selected: null,
        selectedPapers: [],
        openUser(id) {
            const src = this.allUsers.find(u => u.id === id);
            this.selected = { ...src };
            this.selectedPapers = this.adviserPapersMap[id] || [];
            this.$dispatch('open-modal', 'user-actions');
        }
    }">

    {{-- Filter bar --}}
    <div class="mb-4">
        <x-ui.card>
            <form method="GET" action="{{ route('admin.users.index') }}" class="flex flex-wrap items-end gap-4">
                <div class="flex-1 min-w-[200px]">
                    <x-form.input name="search" label="Search" placeholder="Name or email" :value="request('search')" />
                </div>
                <div class="w-44">
                    <x-form.select
                        name="role"
                        label="Role"
                        :options="['admin' => 'Admin', 'adviser' => 'Adviser', 'student' => 'Student']"
                        :selected="request('role')"
                        :placeholder="config('ui.placeholders.all_roles')"
                    />
                </div>
                <div class="flex items-center gap-2 pb-0.5">
                    <x-ui.button type="submit" size="sm">Filter</x-ui.button>
                    @if(request()->hasAny(['search', 'role']))
                        <x-ui.button :href="route('admin.users.index')" variant="ghost" size="sm">Clear</x-ui.button>
                    @endif
                </div>
            </form>
        </x-ui.card>
    </div>

    {{-- 2-column: left = users + pending, right = create panel --}}
    <div class="grid grid-cols-1 lg:grid-cols-4 gap-4 items-start">

        {{-- Active users table + Pending requests --}}
        <div class="lg:col-span-3 space-y-4">

            <x-table.wrapper :paginator="$users">
                <x-slot:head>
                    <x-table.heading class="w-1/3">Name</x-table.heading>
                    <x-table.heading class="hidden md:table-cell">Email</x-table.heading>
                    <x-table.heading>Role</x-table.heading>
                    <x-table.heading class="hidden sm:table-cell">Course</x-table.heading>
                    <x-table.heading class="hidden sm:table-cell">Joined</x-table.heading>
                    <x-table.heading></x-table.heading>
                </x-slot:head>

                @forelse($users as $user)
                    <tr>
                        <x-table.cell class="font-medium text-gray-900">
                            <span class="block truncate" title="{{ $user->first_name }} {{ $user->last_name }}">
                                {{ $user->first_name }} {{ $user->last_name }}
                            </span>
                            @if($user->role === 'admin' && $user->is_adviser)
                                <x-ui.badge status="adviser" class="ml-1" />
                            @endif
                        </x-table.cell>
                        <x-table.cell class="hidden md:table-cell text-gray-500 truncate">{{ $user->email }}</x-table.cell>
                        <x-table.cell><x-ui.badge :status="$user->role" /></x-table.cell>
                        <x-table.cell class="hidden sm:table-cell">{{ $user->course->name ?? 'N/A' }}</x-table.cell>
                        <x-table.cell class="hidden sm:table-cell tabular-nums text-gray-500 whitespace-nowrap"><x-ui.date :value="$user->created_at" /></x-table.cell>
                        <x-table.cell>
                            <x-ui.button type="button" variant="ghost" size="sm"
                                x-on:click="openUser({{ $user->id }})">Manage</x-ui.button>
                        </x-table.cell>
                    </tr>
                @empty
                    <x-table.empty colspan="6" message="No users found." />
                @endforelse
            </x-table.wrapper>

            {{-- Pending requests --}}
            <div>
                <div class="flex items-center justify-between mb-2">
                    <h3 class="text-sm font-semibold text-gray-700">Pending Account Requests</h3>
                    @if($pendingUsers->isNotEmpty())
                        <span class="text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md">
                            {{ $pendingUsers->count() }} pending
                        </span>
                    @endif
                </div>

                @if($pendingUsers->isEmpty())
                    <div class="border border-gray-200 rounded-lg px-4 py-6 text-center text-sm text-gray-400">
                        No pending account requests.
                    </div>
                @else
                    <div class="max-h-64 overflow-y-auto border border-gray-200 rounded-lg">
                        <table class="min-w-full table-fixed divide-y divide-gray-200">
                            <thead class="sticky top-0 bg-white z-10 border-b border-gray-200">
                                <tr>
                                    <x-table.heading class="w-1/3">Name</x-table.heading>
                                    <x-table.heading class="hidden md:table-cell">Email</x-table.heading>
                                    <x-table.heading>Role</x-table.heading>
                                    <x-table.heading class="hidden sm:table-cell">Course</x-table.heading>
                                    <x-table.heading class="hidden sm:table-cell">Joined</x-table.heading>
                                    <x-table.heading></x-table.heading>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach($pendingUsers as $pUser)
                                    <tr>
                                        <x-table.cell class="font-medium text-gray-900">
                                            <span class="block truncate">{{ $pUser->first_name }} {{ $pUser->last_name }}</span>
                                        </x-table.cell>
                                        <x-table.cell class="hidden md:table-cell text-gray-500 truncate">{{ $pUser->email }}</x-table.cell>
                                        <x-table.cell><x-ui.badge :status="$pUser->role" /></x-table.cell>
                                        <x-table.cell class="hidden sm:table-cell">{{ $pUser->course->name ?? 'N/A' }}</x-table.cell>
                                        <x-table.cell class="hidden sm:table-cell tabular-nums text-gray-500 whitespace-nowrap"><x-ui.date :value="$pUser->created_at" /></x-table.cell>
                                        <x-table.cell>
                                            <x-ui.button type="button" variant="ghost" size="sm"
                                                x-on:click="openUser({{ $pUser->id }})">Review</x-ui.button>
                                        </x-table.cell>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>

        </div>

        {{-- Create user sidebar --}}
        <div class="lg:col-span-1">
            <x-admin.user-create-panel :courses="$courses" />
        </div>

    </div>

    {{-- User actions modal --}}
    <x-admin.user-actions-modal :courses="$courses" />

    </div>

</x-layouts.app>
