<x-layouts.app title="Course Management">

    <x-layouts.page-header title="Course Management" subtitle="Manage academic programs" />

    <div x-data="{
        courses: @js($courses->map(fn($c) => ['id' => $c->id, 'code' => $c->code, 'name' => $c->name, 'papers' => $c->research_papers_count ?? 0])),
        selected: null,
        openCourse(id) {
            this.selected = { ...this.courses.find(c => c.id === id) };
            this.$dispatch('open-modal', 'course-actions');
        }
    }">

    {{-- Filter bar --}}
    <div class="mb-4">
        <x-ui.card>
            <form method="GET" action="{{ route('admin.courses.index') }}" class="flex flex-wrap items-end gap-4">
                <div class="flex-1 min-w-[200px]">
                    <x-form.input
                        name="search"
                        label="Search"
                        placeholder="Code or name"
                        :value="request('search')"
                    />
                </div>
                <div class="flex items-center gap-2 pb-0.5">
                    <x-ui.button type="submit" size="sm">Filter</x-ui.button>
                    @if(request()->filled('search'))
                        <x-ui.button :href="route('admin.courses.index')" variant="ghost" size="sm">Clear</x-ui.button>
                    @endif
                </div>
            </form>
        </x-ui.card>
    </div>

    {{-- Main 2-column: left = table, right = add form --}}
    <div class="grid grid-cols-1 lg:grid-cols-4 gap-4 items-start">

        {{-- Left: Courses table --}}
        <div class="lg:col-span-3">
            <x-table.wrapper>
                <x-slot:head>
                    <x-table.heading>Code</x-table.heading>
                    <x-table.heading>Name</x-table.heading>
                    <x-table.heading>Papers</x-table.heading>
                    <x-table.heading></x-table.heading>
                </x-slot:head>

                @forelse($courses as $course)
                    <tr>
                        <x-table.cell class="font-medium text-gray-900">{{ $course->code }}</x-table.cell>
                        <x-table.cell>{{ $course->name }}</x-table.cell>
                        <x-table.cell class="tabular-nums text-gray-500">{{ $course->research_papers_count }}</x-table.cell>
                        <x-table.cell>
                            <x-ui.button type="button" variant="ghost" size="sm"
                                x-on:click="openCourse({{ $course->id }})">
                                Manage
                            </x-ui.button>
                        </x-table.cell>
                    </tr>
                @empty
                    <x-table.empty colspan="4" message="No courses found." />
                @endforelse
            </x-table.wrapper>
        </div>

        {{-- Right: Add Course form --}}
        <div class="lg:col-span-1">
            <x-ui.card title="Add Course">
                <form method="POST" action="{{ route('admin.courses.store') }}" class="space-y-4">
                    @csrf

                    <x-form.input
                        name="code"
                        label="Course Code"
                        placeholder="e.g. IT"
                        :value="old('code')"
                        :required="true"
                    />
                    <x-form.input
                        name="name"
                        label="Course Name"
                        placeholder="e.g. Information Technology"
                        :value="old('name')"
                        :required="true"
                    />

                    <x-ui.button type="submit" variant="primary" class="w-full justify-center">
                        Add Course
                    </x-ui.button>
                </form>
            </x-ui.card>
        </div>

    </div>

    {{-- Single course actions modal --}}
    <x-ui.modal name="course-actions" maxWidth="md">
        <template x-if="selected">
            <x-ui.modal-actions modalName="course-actions">
                <x-slot:title>
                    <h2 class="text-sm font-semibold text-gray-900 leading-snug truncate" x-text="selected.code"></h2>
                    <p class="mt-0.5 text-xs text-gray-500 truncate" x-text="selected.name"></p>
                </x-slot:title>
                <x-slot:tabs>
                    <x-ui.modal-tab key="view" label="View" />
                    <x-ui.modal-tab key="edit" label="Manage" />
                </x-slot:tabs>

                {{-- View panel --}}
                <div x-show="mode === 'view'" x-cloak class="px-6 py-5">
                    <div class="divide-y divide-gray-100 text-sm">
                        <x-ui.detail-field label="Code">
                            <p class="font-medium text-gray-900" x-text="selected.code"></p>
                        </x-ui.detail-field>
                        <x-ui.detail-field label="Name">
                            <p class="font-medium text-gray-900" x-text="selected.name"></p>
                        </x-ui.detail-field>
                        <x-ui.detail-field label="Papers">
                            <p class="text-gray-900 tabular-nums" x-text="selected.papers"></p>
                        </x-ui.detail-field>
                    </div>
                </div>

                {{-- Edit panel --}}
                <div x-show="mode === 'edit'" x-cloak>
                    <form method="POST" :action="'{{ url('admin/courses') }}/' + selected.id">
                        @csrf
                        @method('PUT')
                        <div class="px-6 pt-5 pb-0 space-y-4">
                            <x-form.input name="code" label="Course Code" :required="true" x-model="selected.code" />
                            <x-form.input name="name" label="Course Name" :required="true" x-model="selected.name" />
                        </div>
                        <x-ui.modal-footer modalName="course-actions" submitLabel="Save Changes" />
                    </form>
                </div>
            </x-ui.modal-actions>
        </template>
    </x-ui.modal>

    </div>

</x-layouts.app>
