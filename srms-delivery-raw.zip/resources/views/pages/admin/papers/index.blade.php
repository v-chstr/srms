<x-layouts.app title="Papers">

    <x-layouts.page-header title="Papers" subtitle="Review and manage all research paper submissions">
        <x-slot:actions>
            <x-ui.button type="button" x-data x-on:click="$dispatch('open-modal', 'paper-upload')">Upload Paper</x-ui.button>
        </x-slot:actions>
    </x-layouts.page-header>

    @php
        $canAdvise = auth()->user()->canAdvise();

        $papersJson = $papers->map(function($p) {
            return [
                'id' => $p->id,
                'title' => $p->title,
                'abstract' => $p->abstract,
                'status' => $p->status,
                'created_at' => $p->created_at->srmsDate(),
                'updated_at' => $p->updated_at->srmsDate(),
                'submitter' => $p->submitter ? ['first_name' => $p->submitter->first_name, 'last_name' => $p->submitter->last_name] : null,
                'course' => $p->course ? ['name' => $p->course->name, 'code' => $p->course->code] : null,
                'adviser' => $p->adviser ? ['first_name' => $p->adviser->first_name, 'last_name' => $p->adviser->last_name] : null,
                'adviser_name' => $p->adviser_name,
                'keywords' => $p->keywords ?? [],
                'authors' => $p->authors->map(fn($a) => ['first_name' => $a->first_name, 'last_name' => $a->last_name, 'is_submitter' => $a->is_submitter])->values()->toArray(),
                'reviews' => $p->reviews->map(fn($r) => [
                    'reviewer' => $r->reviewer ? ['first_name' => $r->reviewer->first_name, 'last_name' => $r->reviewer->last_name] : null,
                    'decision' => $r->decision,
                    'comments' => $r->comments,
                    'created_at' => $r->created_at->srmsDate(),
                ])->values()->toArray(),
            ];
        });
    @endphp

    <div x-data="{
        papers: @js($papersJson),
        paper: null,
        openPaper(id) {
            const src = this.papers.find(p => p.id === id);
            this.paper = { ...src, authors: [...(src.authors || [])], reviews: [...(src.reviews || [])] };
            this.$dispatch('open-modal', 'paper-actions');
        }
    }">

    {{-- Filters --}}
    <div class="mb-4">
        <x-ui.card>
            <form method="GET" action="{{ route('admin.papers.index') }}" class="flex flex-wrap items-end gap-4">
                <div class="w-40">
                    <x-form.select
                        name="status"
                        label="Status"
                        :options="['pending' => 'Pending', 'revision' => 'Revision', 'approved' => 'Approved']"
                        :selected="request('status')"
                        :placeholder="config('ui.placeholders.all_statuses')"
                    />
                </div>
                <div class="w-48">
                    <x-form.select
                        name="course_id"
                        label="Course"
                        :options="$courses->pluck('name', 'id')->toArray()"
                        :selected="request('course_id')"
                        :placeholder="config('ui.placeholders.all_courses')"
                    />
                </div>
                <div class="flex items-center gap-2">
                    <x-ui.button type="submit" size="sm">Filter</x-ui.button>
                    @if(request()->hasAny(['status', 'course_id']))
                        <x-ui.button :href="route('admin.papers.index')" variant="ghost" size="sm">Clear</x-ui.button>
                    @endif
                </div>
            </form>
        </x-ui.card>
    </div>

    {{-- Papers table --}}
    <x-table.wrapper :paginator="$papers">
        <x-slot:head>
            <x-table.heading class="w-[42%]">Paper</x-table.heading>
            <x-table.heading class="w-[12%]">Course</x-table.heading>
            <x-table.heading class="w-[18%]">Adviser</x-table.heading>
            <x-table.heading class="w-[12%]">Status</x-table.heading>
            <x-table.heading class="w-[11%]">Submitted</x-table.heading>
            <x-table.heading class="w-[5%]"></x-table.heading>
        </x-slot:head>

        @if($papers->isEmpty())
            <x-table.empty :colspan="6" message="No submissions found. Try adjusting your filters." />
        @else
            @foreach($papers as $p)
                <tr class="cursor-pointer hover:bg-gray-50 transition-colors" x-on:click="openPaper({{ $p->id }})">
                    <x-table.cell>
                        <p class="font-medium text-gray-900 leading-snug truncate">{{ $p->title }}</p>
                        <p class="mt-0.5 text-xs text-gray-500 truncate">
                            {{ $p->submitter ? $p->submitter->last_name . ', ' . $p->submitter->first_name : 'N/A' }}
                        </p>
                        @if($p->authors->isNotEmpty())
                            <p class="mt-0.5 text-xs text-gray-400 truncate">
                                {{ $p->authors->map(fn($a) => $a->last_name . ', ' . $a->first_name)->implode(' · ') }}
                            </p>
                        @endif
                    </x-table.cell>
                    <x-table.cell>
                        <span class="text-xs text-gray-600">{{ $p->course->code ?? 'N/A' }}</span>
                    </x-table.cell>
                    <x-table.cell>
                        @if($p->adviser)
                            <span class="text-xs text-gray-700">{{ $p->adviser->last_name }}, {{ $p->adviser->first_name }}</span>
                        @elseif($p->adviser_name)
                            <span class="text-xs text-gray-700">{{ $p->adviser_name }}</span>
                        @else
                            <span class="text-xs text-gray-400">{{ config('ui.fallbacks.not_assigned') }}</span>
                        @endif
                    </x-table.cell>
                    <x-table.cell>
                        <x-ui.badge :status="$p->status" />
                    </x-table.cell>
                    <x-table.cell>
                        <span class="text-xs text-gray-500 tabular-nums whitespace-nowrap"><x-ui.date :value="$p->created_at" /></span>
                    </x-table.cell>
                    <x-table.cell>
                        <x-ui.button type="button" variant="ghost" size="sm" x-on:click.stop="openPaper({{ $p->id }})">View</x-ui.button>
                    </x-table.cell>
                </tr>
            @endforeach
        @endif
    </x-table.wrapper>

    {{-- Paper detail modal (view only for non-advisers) --}}
    <x-ui.modal name="paper-actions" maxWidth="2xl">
        <template x-if="paper">
            <div>
                <div class="flex items-start justify-between border-b border-gray-200 px-5 py-4 shrink-0">
                    <div class="min-w-0 flex-1 pr-4">
                        <h2 class="text-sm font-semibold text-gray-900 leading-snug truncate" x-text="paper.title"></h2>
                        <p class="mt-0.5 text-xs text-gray-500 truncate"
                           x-text="(paper.submitter ? paper.submitter.first_name + ' ' + paper.submitter.last_name : 'N/A') + ' | ' + (paper.course ? paper.course.name : 'N/A')"></p>
                    </div>
                    <button type="button" x-on:click="$dispatch('close-modal', 'paper-actions')"
                            class="shrink-0 mt-0.5 text-gray-400 hover:text-gray-600 transition-colors">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>
                <x-ui.paper-detail downloadUrlBase="/admin/papers" />

                <div class="flex items-center justify-end gap-3 px-5 py-4 border-t border-gray-100">
                    <form method="POST" :action="'/admin/papers/' + paper.id"
                          x-data="{ confirm: false }"
                          @submit.prevent="if(confirm) $el.submit(); else confirm = true">
                        @csrf
                        @method('DELETE')
                        <button type="submit"
                                :class="confirm ? 'bg-red-600 hover:bg-red-700 text-white' : 'text-red-600 hover:bg-red-50'"
                                class="px-3 py-1.5 text-sm font-medium rounded-md border border-red-200 transition-colors"
                                x-text="confirm ? 'Click again to confirm' : 'Delete Paper'">
                        </button>
                    </form>
                </div>
            </div>
        </template>
    </x-ui.modal>

    </div>

    {{-- Upload paper modal --}}
    <x-ui.modal name="paper-upload" maxWidth="2xl">
        <x-admin.paper-upload-modal :courses="$courses" :keyword-suggestions="$keywordSuggestions" :advisers="$advisers" />
    </x-ui.modal>

</x-layouts.app>
