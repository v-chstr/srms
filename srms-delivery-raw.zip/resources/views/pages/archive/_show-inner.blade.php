{{--
    Shared inner content for archive/show.
    Included by both @auth and @else branches of show.blade.php.
    Variables: $paper, $citations
--}}

{{-- Back link --}}
<a href="{{ route('archive.index') }}" class="inline-flex items-center gap-1 text-xs font-medium text-gray-500 hover:text-gray-900 mb-4">
    <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
        <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
    </svg>
    Back to Archive
</a>

{{-- Two-column layout: thumbnail + main content --}}
<div class="grid grid-cols-1 lg:grid-cols-12 gap-6">

    {{-- Left column: cover thumbnail + actions --}}
    <aside class="lg:col-span-3">
        <div class="rounded-lg border border-gray-200 bg-white overflow-hidden">
            <div class="relative aspect-[3/4] bg-gray-100 border-b border-gray-200">
                @if($paper->thumbnail_path)
                    <img src="{{ route('archive.thumbnail', $paper->id) }}"
                         alt="{{ $paper->title }}"
                         class="absolute inset-0 w-full h-full object-cover object-top" />
                @else
                    <div class="absolute inset-0 flex flex-col items-center justify-center text-gray-300 bg-gradient-to-br from-gray-50 to-gray-100">
                        <svg class="h-12 w-12" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                        </svg>
                        <span class="mt-2 text-xs">PDF</span>
                    </div>
                @endif
            </div>
            <div class="p-3">
                <a href="{{ route('archive.download', $paper->id) }}"
                   class="flex w-full items-center justify-center gap-1.5 rounded-md bg-primary-600 px-3 py-2 text-sm font-medium text-white hover:bg-primary-700">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
                    </svg>
                    Download PDF
                </a>
            </div>
        </div>

        {{-- Quick details --}}
        <dl class="mt-4 rounded-lg border border-gray-200 bg-white divide-y divide-gray-100">
            <div class="px-3 py-2.5">
                <dt class="text-xs font-medium text-gray-500">Program</dt>
                <dd class="mt-0.5 text-sm text-gray-900">{{ $paper->course->name ?? 'N/A' }}</dd>
            </div>
            <div class="px-3 py-2.5">
                <dt class="text-xs font-medium text-gray-500">Year</dt>
                <dd class="mt-0.5 text-sm text-gray-900 tabular-nums">{{ $paper->published_year ?? $paper->created_at->year }}</dd>
            </div>
            <div class="px-3 py-2.5">
                <dt class="text-xs font-medium text-gray-500">Adviser</dt>
                <dd class="mt-0.5 text-sm text-gray-900">
                                    @if($paper->adviser)
                        {{ $paper->adviser->first_name }} {{ $paper->adviser->last_name }}
                    @elseif($paper->adviser_name)
                        {{ $paper->adviser_name }}
                    @else
                        Not Indicated
                    @endif
                </dd>
            </div>
            <div class="px-3 py-2.5">
                <dt class="text-xs font-medium text-gray-500">Submitted</dt>
                <dd class="mt-0.5 text-sm text-gray-900">{{ $paper->created_at->format('M j, Y') }}</dd>
            </div>
        </dl>
    </aside>

    {{-- Right column: title, abstract, citations --}}
    <div class="lg:col-span-9 space-y-6">

        {{-- Title block --}}
        <header class="rounded-lg border border-gray-200 bg-white p-5">
            <div class="flex items-center gap-2 mb-2">
                @if($paper->course)
                    <span class="inline-block bg-primary-50 text-primary-700 text-xs font-medium px-2 py-0.5 rounded-md">{{ $paper->course->code ?? $paper->course->name }}</span>
                @endif
                <span class="text-xs text-gray-400 tabular-nums">{{ $paper->published_year ?? $paper->created_at->year }}</span>
            </div>
            <h1 class="text-xl font-semibold text-gray-900 leading-snug sm:text-2xl">{{ $paper->title }}</h1>
            @if($paper->authors->isNotEmpty())
                <p class="mt-3 text-sm text-gray-600">
                    {{ $paper->authors->map(fn ($a) => $a->first_name . ' ' . $a->last_name)->implode(', ') }}
                </p>
            @endif
        </header>

        {{-- Abstract --}}
        <section class="rounded-lg border border-gray-200 bg-white p-5">
            <h2 class="text-xs font-semibold text-gray-500 mb-3">Abstract</h2>
            @if($paper->abstract)
                <p class="text-sm text-gray-700 leading-relaxed whitespace-pre-line">{{ $paper->abstract }}</p>
            @else
                <p class="text-sm text-gray-400 italic">No abstract provided.</p>
            @endif

            @if($paper->keywords)
                <div class="mt-5 pt-4 border-t border-gray-100">
                    <h3 class="text-xs font-semibold text-gray-500 mb-2">Keywords</h3>
                    <div class="flex flex-wrap gap-1.5">
                        @foreach($paper->keywords as $kw)
                            <span class="inline-block bg-gray-100 text-gray-700 text-xs px-2.5 py-1 rounded-md">{{ $kw }}</span>
                        @endforeach
                    </div>
                </div>
            @endif
        </section>

        {{-- Citation generator --}}
        <section class="rounded-lg border border-gray-200 bg-white p-5" x-data="{ format: 'apa', copied: false }">
            <div class="flex items-center justify-between mb-3">
                <h2 class="text-xs font-semibold text-gray-500">Cite this paper</h2>
                <div class="flex gap-1">
                    @foreach(['apa' => 'APA', 'mla' => 'MLA', 'chicago' => 'Chicago'] as $key => $label)
                        <button type="button" @click="format = '{{ $key }}'"
                                :class="format === '{{ $key }}' ? 'bg-primary-50 text-primary-700 border-primary-200' : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-50'"
                                class="px-2.5 py-1 text-xs font-medium rounded-md border transition-colors">
                            {{ $label }}
                        </button>
                    @endforeach
                </div>
            </div>

            <div class="bg-gray-50 border border-gray-100 rounded-md p-4 text-sm text-gray-700 leading-relaxed">
                <p x-show="format === 'apa'" x-cloak>{{ $citations['apa'] }}</p>
                <p x-show="format === 'mla'" x-cloak>{{ $citations['mla'] }}</p>
                <p x-show="format === 'chicago'" x-cloak>{{ $citations['chicago'] }}</p>
            </div>

            <button type="button"
                @click="
                    const text = format === 'apa' ? @js($citations['apa']) : format === 'mla' ? @js($citations['mla']) : @js($citations['chicago']);
                    navigator.clipboard.writeText(text);
                    copied = true;
                    setTimeout(() => copied = false, 2000);
                "
                class="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-200 rounded-md hover:bg-gray-50">
                <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9.75a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184" />
                </svg>
                <span x-text="copied ? 'Copied' : 'Copy citation'"></span>
            </button>
        </section>

    </div>
</div>
