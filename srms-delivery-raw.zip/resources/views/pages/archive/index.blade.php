﻿@auth
<x-layouts.app title="Research Archive">
    @include('pages.archive._index-inner')
</x-layouts.app>
@else
<x-layouts.stage title="Research Archive">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
        @include('pages.archive._index-inner')
    </div>
</x-layouts.stage>
@endauth
