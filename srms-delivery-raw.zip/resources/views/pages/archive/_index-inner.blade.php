{{--
    Shared inner content for archive/index.
    Included by both @auth and @else branches of index.blade.php.
    Variables: $papers, $courses, $years
--}}

{{-- Compact header + result count --}}
<div class="mb-4 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
    <div>
        <h1 class="text-lg font-semibold text-gray-900">Research Archive</h1>
        <p class="text-xs text-gray-500 mt-0.5">Browse approved research from the SITE department</p>
    </div>
    <p class="text-xs text-gray-500 tabular-nums shrink-0">
        {{ $papers->total() }} {{ Str::plural('paper', $papers->total()) }}
        @if(request('search'))
            matching "{{ request('search') }}"
        @endif
    </p>
</div>

{{-- Single-row filter bar — no labels, placeholders handle context --}}
<form method="GET" action="{{ route('archive.index') }}"
      class="mb-5 grid grid-cols-2 gap-2 rounded-lg border border-gray-200 bg-white p-3 sm:grid-cols-12">

    {{-- Search --}}
    <div class="relative col-span-2 sm:col-span-5">
        <svg class="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
            <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
        </svg>
        <input type="text" name="search" value="{{ request('search') }}"
               placeholder="Search title, abstract, keywords"
               class="w-full rounded-md border border-gray-300 py-2 pl-8 pr-3 text-sm text-gray-900 placeholder:text-gray-400 focus:border-primary-500 focus:ring-1 focus:ring-primary-500" />
    </div>

    {{-- Program --}}
    <div class="sm:col-span-3">
        <select name="course_id" class="block w-full rounded-md border border-gray-300 py-2 pl-3 pr-8 text-sm text-gray-900 focus:border-primary-500 focus:ring-1 focus:ring-primary-500">
            <option value="">All programs</option>
            @foreach($courses as $id => $name)
                <option value="{{ $id }}" @selected(request('course_id') == $id)>{{ $name }}</option>
            @endforeach
        </select>
    </div>

    {{-- Year --}}
    <div class="sm:col-span-2">
        <select name="year" class="block w-full rounded-md border border-gray-300 py-2 pl-3 pr-8 text-sm text-gray-900 focus:border-primary-500 focus:ring-1 focus:ring-primary-500">
            <option value="">All years</option>
            @foreach($years as $y)
                <option value="{{ $y }}" @selected(request('year') == $y)>{{ $y }}</option>
            @endforeach
        </select>
    </div>

    {{-- Sort --}}
    <div class="sm:col-span-2">
        <select name="sort" class="block w-full rounded-md border border-gray-300 py-2 pl-3 pr-8 text-sm text-gray-900 focus:border-primary-500 focus:ring-1 focus:ring-primary-500">
            <option value="newest" @selected(request('sort', 'newest') === 'newest')>Newest first</option>
            <option value="oldest" @selected(request('sort') === 'oldest')>Oldest first</option>
            <option value="title" @selected(request('sort') === 'title')>Title (A-Z)</option>
        </select>
    </div>

    {{-- Actions --}}
    <div class="col-span-2 flex items-center gap-2 sm:col-span-12 sm:justify-end">
        <button type="submit" class="inline-flex items-center px-3 py-1.5 text-sm font-medium text-white bg-primary-600 rounded-md hover:bg-primary-700">Apply filters</button>
        @if(request()->hasAny(['search', 'course_id', 'year', 'sort']))
            <a href="{{ route('archive.index') }}" class="text-xs font-medium text-gray-500 hover:text-gray-900">Clear all</a>
        @endif
    </div>
</form>

{{-- Results --}}
@if($papers->isEmpty())
    <div class="rounded-lg border border-gray-200 bg-white px-6 py-16 text-center">
        <svg class="mx-auto h-10 w-10 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1">
            <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
        </svg>
        <p class="mt-3 text-sm text-gray-500">No papers found matching your criteria.</p>
        <a href="{{ route('archive.index') }}" class="mt-2 inline-block text-xs font-medium text-primary-600 hover:text-primary-800">Clear filters</a>
    </div>
@else
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
        @foreach($papers as $paper)
            <x-archive.paper-card :paper="$paper" />
        @endforeach
    </div>

    <div class="mt-6">
        {{ $papers->links() }}
    </div>
@endif
