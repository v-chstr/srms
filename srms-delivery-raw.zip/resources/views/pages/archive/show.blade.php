﻿@auth
<x-layouts.app :title="$paper->title">
    @include('pages.archive._show-inner')
</x-layouts.app>
@else
<x-layouts.stage :title="$paper->title">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
        @include('pages.archive._show-inner')
    </div>
</x-layouts.stage>
@endauth
