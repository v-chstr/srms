<x-layouts.app title="Review Queue">

    <x-layouts.page-header title="Review Queue" subtitle="Research papers available for review" />

    @php
        $papersJson = $papers->map(fn ($p) => [
            'id' => $p->id,
            'title' => $p->title,
            'abstract' => $p->abstract,
            'status' => $p->status,
            'created_at' => $p->created_at->srmsDate(),
            'updated_at' => $p->updated_at->srmsDate(),
            'submitter' => $p->submitter ? ['first_name' => $p->submitter->first_name, 'last_name' => $p->submitter->last_name] : null,
            'course' => $p->course ? ['code' => $p->course->code, 'name' => $p->course->name] : null,
            'adviser' => $p->adviser ? ['first_name' => $p->adviser->first_name, 'last_name' => $p->adviser->last_name] : null,
            'adviser_name' => $p->adviser_name,
            'keywords' => $p->keywords ?? [],
            'authors' => $p->authors->map(fn ($a) => ['first_name' => $a->first_name, 'last_name' => $a->last_name, 'is_submitter' => $a->is_submitter])->values()->toArray(),
            'reviews' => $p->reviews->map(fn ($r) => [
                'decision' => $r->decision,
                'comment' => $r->comment,
                'created_at' => $r->created_at->srmsDate(),
                'reviewer' => $r->reviewer ? ['first_name' => $r->reviewer->first_name, 'last_name' => $r->reviewer->last_name] : null,
            ])->values()->toArray(),
        ]);
    @endphp

    <div x-data="{
        papers: @js($papersJson),
        paper: null,
        openPaper(id) {
            this.paper = null;
            this.$nextTick(() => {
                const src = this.papers.find(p => p.id === id);
                this.paper = { ...src, authors: [...(src.authors || [])], reviews: [...(src.reviews || [])] };
                this.$dispatch('open-modal', 'review-actions');
            });
        }
    }">

    {{-- Filters --}}
    <div class="mb-5">
        <form method="GET" action="{{ route('adviser.reviews.index') }}" class="flex flex-wrap items-end gap-3">
            <div class="w-48">
                <x-form.select
                    name="course_id"
                    label="Course"
                    :options="$courses->pluck('name', 'id')->toArray()"
                    :selected="$courseFilter"
                    :placeholder="config('ui.placeholders.all_courses')"
                />
            </div>
            <div class="w-40">
                <x-form.select
                    name="status"
                    label="Status"
                    :options="collect(config('ui.statuses'))->pluck('label')->all()"
                    :selected="request('status')"
                    :placeholder="config('ui.placeholders.all_statuses')"
                />
            </div>
            <x-ui.button type="submit" size="sm">Filter</x-ui.button>
            @if(request('course_id') || request('status') || $autoFiltered)
                <a href="{{ route('adviser.reviews.index', ['course_id' => '']) }}" class="text-sm text-primary-600 hover:text-primary-800">Clear filters</a>
            @endif
        </form>
        @if($autoFiltered)
            <p class="mt-2 text-xs text-gray-500">Auto-filtered to your assigned course. Use the filter above to view other courses.</p>
        @endif
    </div>

    @if($papers->isEmpty())
        <x-ui.card>
            <div class="text-center py-8">
                <p class="text-sm text-gray-500">No papers found matching your filters.</p>
            </div>
        </x-ui.card>
    @else
        <x-table.wrapper>
            <x-slot:head>
                <x-table.heading class="w-2/5">Title</x-table.heading>
                <x-table.heading class="hidden sm:table-cell">Submitted By</x-table.heading>
                <x-table.heading class="hidden md:table-cell">Course</x-table.heading>
                <x-table.heading class="hidden lg:table-cell">Adviser</x-table.heading>
                <x-table.heading>Status</x-table.heading>
                <x-table.heading class="hidden sm:table-cell">Submitted</x-table.heading>
                <x-table.heading></x-table.heading>
            </x-slot:head>

            @foreach($papers as $paper)
                <tr>
                    <x-table.cell class="font-medium text-gray-900">
                        <button type="button" class="hover:text-primary-700 text-left truncate block w-full" title="{{ $paper->title }}" x-on:click="openPaper({{ $paper->id }})">
                            {{ $paper->title }}
                        </button>
                        @if($paper->authors->isNotEmpty())
                            <p class="mt-0.5 text-xs text-gray-400 truncate">
                                {{ $paper->authors->map(fn($a) => $a->last_name . ', ' . $a->first_name)->implode(' · ') }}
                            </p>
                        @endif
                    </x-table.cell>
                    <x-table.cell class="hidden sm:table-cell">{{ $paper->submitter->first_name }} {{ $paper->submitter->last_name }}</x-table.cell>
                    <x-table.cell class="hidden md:table-cell">{{ $paper->course->code ?? 'N/A' }}</x-table.cell>
                    <x-table.cell class="hidden lg:table-cell">{{ $paper->adviser ? $paper->adviser->first_name . ' ' . $paper->adviser->last_name : ($paper->adviser_name ?: config('ui.fallbacks.not_assigned')) }}</x-table.cell>
                    <x-table.cell><x-ui.badge :status="$paper->status" /></x-table.cell>
                    <x-table.cell class="hidden sm:table-cell whitespace-nowrap"><x-ui.date :value="$paper->created_at" /></x-table.cell>
                    <x-table.cell>
                        <x-ui.button type="button" variant="ghost" size="sm" x-on:click="openPaper({{ $paper->id }})">Review</x-ui.button>
                    </x-table.cell>
                </tr>
            @endforeach
        </x-table.wrapper>

        <div class="mt-4">
            {{ $papers->links() }}
        </div>
    @endif

    {{-- Single review actions modal --}}
    <x-ui.modal name="review-actions" maxWidth="2xl">
        <template x-if="paper">
            <x-ui.modal-actions modalName="review-actions">
                <x-slot:title>
                    <h2 class="text-sm font-semibold text-gray-900 leading-snug truncate" x-text="paper.title"></h2>
                    <p class="mt-0.5 text-xs text-gray-500 truncate"
                       x-text="(paper.submitter ? paper.submitter.first_name + ' ' + paper.submitter.last_name : 'N/A') + ' | ' + (paper.course ? paper.course.code : 'N/A')"></p>
                </x-slot:title>
                <x-slot:tabs>
                    <x-ui.modal-tab key="view" label="View Details" />
                    <template x-if="paper.status !== 'approved'">
                        <x-ui.modal-tab key="review" label="Submit Review" />
                    </template>
                </x-slot:tabs>

                {{-- View panel --}}
                <div x-show="mode === 'view'" x-cloak>
                    <x-ui.paper-detail downloadUrlBase="/adviser/reviews" />
                </div>

                {{-- Review panel --}}
                <div x-show="mode === 'review'" x-cloak>
                    <form method="POST" :action="'{{ url('adviser/reviews') }}/' + paper.id"
                          x-data="{ submitting: false }" @submit="submitting = true">
                        @csrf
                        <div class="px-6 pt-5 pb-0 space-y-4">
                            <x-form.textarea
                                name="comments"
                                label="Review Comments"
                                placeholder="Provide your feedback on this research paper"
                                :required="true"
                                rows="5"
                            />
                            <x-form.select
                                name="decision"
                                label="Decision"
                                :required="true"
                                :options="config('ui.review_decisions')"
                                placeholder="Select a decision"
                            />
                        </div>
                        <div class="px-6 pb-5 pt-4 flex justify-end gap-3">
                            <x-ui.button type="button" variant="secondary" x-on:click="$dispatch('close-modal', 'review-actions')">Cancel</x-ui.button>
                            <x-ui.button type="submit"
                                x-bind:disabled="submitting"
                                x-bind:class="submitting ? 'opacity-50 cursor-not-allowed' : ''">
                                <template x-if="submitting">
                                    <svg class="animate-spin h-4 w-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path>
                                    </svg>
                                </template>
                                <span x-text="submitting ? 'Submitting...' : 'Submit Review'"></span>
                            </x-ui.button>
                        </div>
                    </form>
                </div>
            </x-ui.modal-actions>
        </template>
    </x-ui.modal>

    </div>

</x-layouts.app>
