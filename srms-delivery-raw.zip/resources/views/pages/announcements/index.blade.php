<x-layouts.app title="Announcements">

    <x-layouts.page-header title="Announcements" subtitle="Current announcements and notices" />

    @php
        $announcementsJson = $announcements->map(fn ($a) => [
            'id'                 => $a->id,
            'title'              => $a->title,
            'message'            => $a->message,
            'course_id'          => $a->course_id,
            'course_name'        => $a->course->name ?? 'All courses',
            'poster_name'        => $a->poster
                                        ? trim($a->poster->first_name . ' ' . $a->poster->last_name)
                                        : 'Unknown',
            'created_at'         => $a->created_at->srmsDateTime(),
            'expires_at'         => $a->expires_at?->format('Y-m-d'),
            'expires_at_display' => $a->expires_at?->srmsDate(),
            'can_manage'         => false,
        ]);
    @endphp

    <div x-data="{
        allAnnouncements: @js($announcementsJson),
        selected: null,
        openAnnouncement(id) {
            this.selected = null;
            this.$nextTick(() => {
                this.selected = { ...this.allAnnouncements.find(a => a.id === id) };
                this.$dispatch('open-modal', 'announcement-actions');
            });
        }
    }">

        {{-- Filter bar --}}
        <div class="mb-4">
            <x-ui.card>
                <form method="GET" action="{{ route('announcements.index') }}" class="flex flex-wrap items-end gap-4">
                    <div class="flex-1 min-w-[200px]">
                        <x-form.input name="search" label="Search" placeholder="Announcement title" :value="request('search')" />
                    </div>
                    <div class="flex items-center gap-2 pb-0.5">
                        <x-ui.button type="submit" size="sm">Filter</x-ui.button>
                        @if(request()->filled('search'))
                            <x-ui.button :href="route('announcements.index')" variant="ghost" size="sm">Clear</x-ui.button>
                        @endif
                    </div>
                </form>
            </x-ui.card>
        </div>

        {{-- Announcement list --}}
        <div class="space-y-2">
            @forelse($announcements as $announcement)
                <div class="bg-white border border-gray-200 rounded-lg px-4 py-3 flex items-center gap-3">
                    <span class="shrink-0 w-6 h-6 flex items-center justify-center rounded-md bg-gray-100 text-xs font-semibold text-gray-500 tabular-nums">
                        {{ $loop->iteration }}
                    </span>
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-medium text-gray-900 truncate" title="{{ $announcement->title }}">
                            {{ $announcement->title }}
                        </p>
                        <p class="text-xs text-gray-500 truncate mt-0.5">
                            {{ $announcement->course->name ?? 'All courses' }}
                            <span class="text-gray-300 mx-1">/</span>
                            {{ trim(($announcement->poster->first_name ?? '') . ' ' . ($announcement->poster->last_name ?? '')) ?: 'Unknown' }}
                        </p>
                    </div>
                    <span class="shrink-0 text-xs text-gray-400 tabular-nums hidden sm:block">
                        <x-ui.date :value="$announcement->created_at" />
                    </span>
                    <x-ui.button type="button" variant="ghost" size="sm" class="shrink-0"
                        x-on:click="openAnnouncement({{ $announcement->id }})">
                        View
                    </x-ui.button>
                </div>
            @empty
                <div class="bg-white border border-gray-200 rounded-lg px-6 py-10 text-center">
                    <p class="text-sm text-gray-400">No announcements found.</p>
                </div>
            @endforelse
        </div>

        {{-- Pagination --}}
        <x-ui.pagination :paginator="$announcements" class="pt-3" />

        {{-- View modal (view-only: can_manage is always false) --}}
        <x-announcements.actions-modal :courses="collect()" manageBaseUrl="" />

    </div>

</x-layouts.app>
