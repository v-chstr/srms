<x-layouts.app title="My Research">

    <x-layouts.page-header title="My Research" subtitle="View and manage your research submissions" />

    @php
        $papersJson = $papers->map(fn ($p) => [
            'id' => $p->id,
            'title' => $p->title,
            'abstract' => $p->abstract,
            'status' => $p->status,
            'adviser_id'   => $p->adviser_id,
            'adviser_name' => $p->adviser_name,
            'created_at' => $p->created_at->srmsDate(),
            'updated_at' => $p->updated_at->srmsDate(),
            'course' => $p->course ? ['code' => $p->course->code, 'name' => $p->course->name] : null,
            'adviser' => $p->adviser ? ['first_name' => $p->adviser->first_name, 'last_name' => $p->adviser->last_name] : null,
            'keywords'          => $p->keywords ?? [],
            'original_filename' => $p->original_filename,
            'file_name'         => $p->file_path ? basename($p->file_path) : null,
            'download_url'      => route('student.research.download', $p->id),
            'authors' => $p->authors->map(fn ($a) => ['first_name' => $a->first_name, 'last_name' => $a->last_name, 'is_submitter' => $a->is_submitter])->values()->toArray(),
            'reviews' => $p->reviews->map(fn ($r) => [
                'decision' => $r->decision,
                'comments' => $r->comments,
                'created_at' => $r->created_at->srmsDate(),
                'reviewer' => $r->reviewer ? ['first_name' => $r->reviewer->first_name, 'last_name' => $r->reviewer->last_name] : null,
            ])->values()->toArray(),
        ]);
    @endphp

    <div x-data="{
        papers: @js($papersJson),
        paper: null,
        openPaper(id) {
            this.paper = null;
            this.$nextTick(() => {
                const src = this.papers.find(p => p.id === id);
                this.paper = { ...src, authors: [...(src.authors || [])], reviews: [...(src.reviews || [])] };
                this.$dispatch('open-modal', 'research-actions');
            });
        }
    }">

    {{-- New Submission button --}}
    <div class="mb-5">
        <button type="button" @click="$dispatch('open-modal', 'research-create')"
                class="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-primary-700 bg-primary-50 border border-primary-200 rounded-lg hover:bg-primary-100 transition-colors">
            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15"/></svg>
            New Submission
        </button>
    </div>

    {{-- Empty state --}}
    @if($papers->isEmpty())
        <div class="text-center py-12">
            <div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-gray-100 mb-4">
                <svg class="h-6 w-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"/>
                </svg>
            </div>
            <p class="text-sm font-medium text-gray-900">No research papers yet</p>
            <p class="text-xs text-gray-500 mt-1">Submit your first research paper to get started.</p>
            <button type="button" @click="$dispatch('open-modal', 'research-create')"
                    class="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-primary-700 bg-primary-50 border border-primary-200 rounded-md hover:bg-primary-100">
                Submit your first paper
            </button>
        </div>
    @else
        {{-- Paper cards --}}
        <div class="space-y-3">
            @foreach($papers as $paper)
                <x-student.research-card :paper="$paper" />
            @endforeach
        </div>

        <div class="mt-4">
            {{ $papers->links() }}
        </div>
    @endif

    {{-- New submission modal --}}
    <x-ui.modal name="research-create" :show="$errors->hasAny(['title', 'abstract', 'manuscript', 'adviser_id', 'adviser_name', 'keywords', 'authors'])" maxWidth="2xl">
        <x-student.research-submit-form :keywordSuggestions="$keywordSuggestions" :advisers="$advisers" />
    </x-ui.modal>

    {{-- View + Edit/Resubmit modal --}}
    <x-student.research-actions-modal />

    </div>

</x-layouts.app>
