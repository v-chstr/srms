<x-layouts.guest title="{{ ($mode ?? 'login') === 'register' ? 'Create Account' : 'Sign In' }}">

    <div class="flex flex-col min-h-screen" x-data="authPage()">

        {{-- Hero / landing header --}}
        <div class="w-full bg-primary-900 px-6 py-8 sm:px-10 sm:py-10">
            <div class="mx-auto max-w-3xl flex flex-col sm:flex-row sm:items-center gap-5 sm:gap-8">
                <img src="{{ asset('images/spup-site.png') }}" alt="SITE" class="h-14 w-14 shrink-0 object-contain sm:h-16 sm:w-16">
                <div>
                    <p class="text-xs font-medium text-primary-400 mb-1">
                        St. Paul University Philippines, SITE
                    </p>
                    <h1 class="text-2xl sm:text-3xl font-bold text-white leading-snug mb-2">
                        Student Research Management System
                    </h1>
                    <p class="text-xs sm:text-sm text-primary-300 leading-relaxed">
                        Submit, review, and archive undergraduate research across all SITE programs.
                    </p>
                </div>
            </div>
        </div>

        {{-- Auth forms --}}
        <div class="flex flex-1 items-center justify-center bg-white px-4 py-8 sm:px-6 sm:py-10">
            <div class="w-full max-w-sm">

                {{-- Login form --}}
                <div x-show="mode === 'login'"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 translate-y-1"
                     x-transition:enter-end="opacity-100 translate-y-0">
                    <div class="mb-8">
                        <h2 class="text-2xl font-semibold text-gray-900">Sign in</h2>
                        <p class="mt-1 text-sm text-gray-500">Access your research portal</p>
                    </div>

                    @if(session('status'))
                        <div class="mb-4">
                            <x-ui.alert type="success">{{ session('status') }}</x-ui.alert>
                        </div>
                    @endif

                    <form method="POST" action="{{ route('login') }}" class="space-y-5">
                        @csrf

                        <div class="space-y-1">
                            <label for="login_email" class="block text-sm font-medium text-gray-700">Email</label>
                            <input id="login_email" type="text" name="email" x-ref="loginEmail"
                                placeholder="you@example.com" required value="{{ old('email', '') }}"
                                class="block w-full border border-gray-300 px-3 py-2 text-sm rounded-md shadow-sm focus:border-primary-500 focus:ring-primary-500 focus:outline-none" />
                            <x-form.error name="email" />
                        </div>

                        <div class="space-y-1">
                            <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                            <div class="relative">
                                <input id="password" name="password" :type="show ? 'text' : 'password'"
                                    placeholder="Enter your password" required x-ref="loginPassword" value=""
                                    class="block w-full border border-gray-300 px-3 py-2 pr-10 text-sm rounded-md shadow-sm focus:border-primary-500 focus:ring-primary-500 focus:outline-none" />
                                <button type="button" @click="show = !show"
                                    class="absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-gray-600"
                                    :aria-label="show ? 'Hide password' : 'Show password'" tabindex="-1">
                                    <svg x-show="!show" class="h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.964-7.178Z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                    </svg>
                                    <svg x-show="show" x-cloak class="h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" />
                                    </svg>
                                </button>
                            </div>
                            <x-form.error name="password" />
                        </div>

                        <x-ui.button type="submit" class="w-full">Sign In</x-ui.button>
                    </form>

                    <p class="mt-6 text-center text-xs text-gray-500">
                        <a href="{{ route('archive.index') }}" class="font-medium text-primary-600 hover:text-primary-800">Browse Research Archive</a> without signing in
                    </p>

                    <p class="mt-4 text-center text-xs text-gray-500">
                        New to SRMS?
                        <button type="button" @click="mode = 'register'" class="font-medium text-primary-600 hover:text-primary-800">Create an account</button>
                    </p>
                </div>

                {{-- Register form --}}
                <div x-show="mode === 'register'" x-cloak
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 translate-y-1"
                     x-transition:enter-end="opacity-100 translate-y-0">
                    <div class="mb-8">
                        <h2 class="text-2xl font-semibold text-gray-900">Create your account</h2>
                        <p class="mt-1 text-sm text-gray-500">Join the SRMS research community</p>
                    </div>

                    <form method="POST" action="{{ route('register') }}" class="space-y-5">
                        @csrf

                        <div class="grid grid-cols-1 min-[380px]:grid-cols-2 gap-4">
                            <x-form.input name="first_name" label="First name" placeholder="Juan" :required="true" />
                            <x-form.input name="last_name" label="Last name" placeholder="Dela Cruz" :required="true" />
                        </div>

                        <x-form.input name="email" type="email" label="Email address" placeholder="you@example.com" :required="true" />

                        <div>
                            <input type="hidden" name="is_student" value="0">
                            <div class="flex items-start gap-2">
                                <input type="checkbox" id="is_student" name="is_student" value="1" x-model="isStudent"
                                    class="mt-0.5 h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500" />
                                <label for="is_student" class="text-sm text-gray-700 select-none">I am a student</label>
                            </div>
                        </div>

                        <div x-show="isStudent" x-transition x-cloak>
                            <x-form.select name="course_id" label="Course / Program" :options="$courses" :required="false" x-bind:required="isStudent" />
                        </div>

                        <x-form.input name="password" type="password" label="Password" placeholder="At least 8 characters" :required="true" />
                        <x-form.input name="password_confirmation" type="password" label="Confirm password" placeholder="Re-enter your password" :required="true" />

                        <x-ui.button type="submit" class="w-full">Create Account</x-ui.button>
                    </form>

                    <p class="mt-6 text-center text-xs text-gray-500">
                        <a href="{{ route('archive.index') }}" class="font-medium text-primary-600 hover:text-primary-800">Browse Research Archive</a> without signing in
                    </p>

                    <p class="mt-4 text-center text-xs text-gray-500">
                        Already have an account?
                        <button type="button" @click="mode = 'login'" class="font-medium text-primary-600 hover:text-primary-800">Sign in</button>
                    </p>
                </div>

            </div>
        </div>

        {{-- Institutional footer --}}
        <div class="px-6 py-3 text-center border-t border-gray-200 bg-gray-50">
            <p class="text-xs font-medium text-gray-500">
                <a href="https://spup.edu.ph" target="_blank" rel="noopener" class="hover:text-primary-600 transition-colors">
                    St. Paul University Philippines
                </a>
            </p>
            <p class="text-xs text-gray-400 mt-1">Tuguegarao City, Cagayan | Est. 1907</p>
            <p class="text-xs text-gray-400 mt-0.5">Caritas, Veritas, Scientia</p>
        </div>
    </div>

    @push('scripts')
    <script>
        function authPage() {
            return {
                mode: '{{ $mode ?? "login" }}',
                show: false,
                isStudent: @json($errors->any() ? (bool) old('is_student') : true),
            }
        }
    </script>
    @endpush

</x-layouts.guest>
