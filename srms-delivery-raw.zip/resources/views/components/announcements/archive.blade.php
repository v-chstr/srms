{{--
    Archived announcements section.
    Requires: Alpine scope from <x-announcements.management> parent (openAnnouncement).
--}}
@props([
    'archivedAnnouncements',
    'ownerId' => null,
])

<div class="mt-4">
    <x-ui.card :compact="true"
        title="Archived Announcements"
        maxHeight="max-h-80"
        :empty="$archivedAnnouncements->isEmpty()"
        emptyText="No archived announcements.">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead>
                    <tr>
                        <x-table.heading>Title</x-table.heading>
                        <x-table.heading>Target</x-table.heading>
                        <x-table.heading>Posted By</x-table.heading>
                        <x-table.heading>Expired On</x-table.heading>
                        <x-table.heading></x-table.heading>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-100">
                    @foreach($archivedAnnouncements as $announcement)
                        <tr>
                            <x-table.cell class="text-gray-400 max-w-xs">
                                <span class="block truncate" title="{{ $announcement->title }}">{{ $announcement->title }}</span>
                            </x-table.cell>
                            <x-table.cell class="text-gray-400">{{ $announcement->course->name ?? 'All courses' }}</x-table.cell>
                            <x-table.cell class="text-gray-400">
                                {{ $announcement->poster->first_name ?? '' }} {{ $announcement->poster->last_name ?? '' }}
                            </x-table.cell>
                            <x-table.cell class="tabular-nums text-gray-400">
                                <x-ui.date :value="$announcement->expires_at" numeric />
                            </x-table.cell>
                            <x-table.cell>
                                <x-ui.button type="button" variant="ghost" size="sm"
                                    x-on:click="openAnnouncement({{ $announcement->id }})">
                                    View
                                </x-ui.button>
                            </x-table.cell>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </x-ui.card>
</div>
