@props([
    'title' => null,
    'compact' => false,
    'viewAllRoute' => null,
    'maxHeight' => null,
    'empty' => false,
    'emptyText' => 'No data available.',
])

<div {{ $attributes->merge(['class' => 'bg-white border border-gray-200 rounded-lg' . ($compact ? ' overflow-hidden h-full' : ' shadow-sm')]) }}>
    @if($title)
        @if($compact)
            <div class="px-4 py-2.5 border-b border-gray-100 flex items-center justify-between">
                <h2 class="text-xs font-semibold text-gray-500">{{ $title }}</h2>
                @if($viewAllRoute)
                    <a href="{{ $viewAllRoute }}" data-nav-link
                       class="text-xs font-medium text-primary-600 hover:text-primary-900">See all</a>
                @endif
            </div>
        @else
            <div class="px-5 py-4 border-b border-gray-200">
                <h3 class="text-sm font-semibold text-gray-900">{{ $title }}</h3>
            </div>
        @endif
    @endif

    @if($empty)
        <div class="px-4 py-8 text-center">
            <p class="text-sm text-gray-400">{{ $emptyText }}</p>
        </div>
    @else
        <div class="{{ $compact ? '' : 'p-5' }} {{ $maxHeight ? "overflow-y-auto {$maxHeight}" : '' }}">
            {{ $slot }}
        </div>
    @endif

    @isset($footer)
        <div class="px-5 py-3 border-t border-gray-100 bg-gray-50">
            {{ $footer }}
        </div>
    @endisset
</div>
