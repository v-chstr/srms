@props(['type' => 'success'])

@php
$styles = match($type) {
    'success' => 'bg-emerald-50 text-emerald-800 border-emerald-200',
    'error'   => 'bg-red-50 text-red-800 border-red-200',
    'warning' => 'bg-amber-50 text-amber-800 border-amber-200',
    'info'    => 'bg-blue-50 text-blue-800 border-blue-200',
    default   => 'bg-gray-50 text-gray-800 border-gray-200',
};
@endphp

<div {{ $attributes->merge(['class' => "border rounded-md px-4 py-3 text-sm font-sans $styles"]) }}
     x-data="{ show: true }"
     x-show="show"
     x-transition:leave="transition ease-in duration-200"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
    <div class="flex items-center justify-between">
        <p>{{ $slot }}</p>
        <button type="button" @click="show = false" class="ml-4 opacity-50 hover:opacity-100">
            <svg class="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
            </svg>
        </button>
    </div>
</div>
