@props(['label'])

<div class="flex items-start gap-x-6 py-2.5" {{ $attributes }}>
    <span class="w-28 shrink-0 text-xs font-semibold text-gray-500 leading-5">{{ $label }}</span>
    <div class="flex-1 min-w-0">{{ $slot }}</div>
</div>
