{{--
    Inner shell for all single-instance Alpine-driven action modals.
    Provides: x-data="{ mode: 'view' }", the dynamic header (Alpine bindings),
    the tab nav sidebar, and the panels area.

    Use inside <template x-if="selected"> (or x-if="paper", etc.)

    Named slots:
      - title  : <h2> + optional <p> with x-text or plain text
      - tabs   : <x-ui.modal-tab> elements
      - (default slot) : panel divs

    Props:
      - modalName : string — used for the close button dispatch
--}}
@props(['modalName'])

<div x-data="{ mode: 'view' }">
    {{-- Header --}}
    <div class="flex items-start justify-between border-b border-gray-200 px-5 py-4 shrink-0">
        <div class="min-w-0 flex-1 pr-4">
            {{ $title }}
        </div>
        <button type="button"
                x-on:click="$dispatch('close-modal', '{{ $modalName }}')"
                class="shrink-0 mt-0.5 text-gray-400 hover:text-gray-600 transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
            </svg>
        </button>
    </div>

    <div class="flex">
        {{-- Tab nav sidebar --}}
        <nav class="w-28 shrink-0 border-r border-gray-100 bg-gray-50/50 py-2 flex flex-col gap-0.5 px-1.5">
            {{ $tabs }}
        </nav>

        {{-- Panel area --}}
        <div class="flex-1 min-w-0">
            {{ $slot }}
        </div>
    </div>
</div>
