@props([
    'status' => 'pending',
    'long'   => false,
])

@php
$statusCfg = config("ui.statuses.$status");
$roleCfg   = config("ui.roles.$status");

if ($statusCfg) {
    $color = $statusCfg['bg'] . ' ' . $statusCfg['text'];
    $label = $long ? $statusCfg['label_long'] : $statusCfg['label'];
} elseif ($roleCfg) {
    $color = $roleCfg['bg'] . ' ' . $roleCfg['text'];
    $label = $roleCfg['label'];
} else {
    $color = match($status) {
        'active' => 'bg-emerald-100 text-emerald-800',
        default  => 'bg-gray-100 text-gray-700',
    };
    $label = ucfirst($status);
}
@endphp

<span {{ $attributes->class(['inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-md', $color]) }}>
    {{ $label }}
</span>
