@props(['items' => []])

{{--
    Stats strip. Each $item is one of:
      - Stat:    ['label' => '...', 'value' => ..., 'color' => '...']
      - Group:   ['group' => true, 'label' => '...', 'items' => [['label' => '...', 'value' => ...], ...]]
      - Divider: ['divider' => true]  ← vertical separator between sections
    To add stats or sections: edit the $statItems array in DashboardController. No changes needed here.
--}}
<div class="rounded-lg border border-gray-200 bg-white overflow-hidden">
    <div class="flex overflow-x-auto stats-scroll-x">
        @foreach($items as $item)
            @if(!empty($item['divider']))
                <div class="w-px self-stretch bg-gray-200 mx-1 shrink-0"></div>

            @elseif(!empty($item['group']))
                {{-- Group cell: label header + row of sub-stats --}}
                <div class="flex-1 min-w-[16rem] px-5 py-3 border-r border-gray-100 last:border-r-0">
                    <p class="text-xs font-semibold text-gray-400 mb-2.5">{{ $item['label'] }}</p>
                    <div class="flex divide-x divide-gray-100">
                        @foreach($item['items'] as $sub)
                            <div class="flex-1 pr-3 last:pr-0 pl-3 first:pl-0">
                                <p class="text-2xl font-bold tabular-nums text-gray-900">{{ $sub['value'] }}</p>
                                <p class="text-xs font-medium text-gray-400 mt-0.5 whitespace-nowrap">{{ $sub['label'] }}</p>
                            </div>
                        @endforeach
                    </div>
                </div>

            @else
                {{-- Plain stat cell --}}
                <div class="flex-1 min-w-[7rem] px-5 py-3 border-r border-gray-100 last:border-r-0">
                    <p class="text-xs font-medium text-gray-500 whitespace-nowrap">{{ $item['label'] }}</p>
                    <p class="mt-0.5 text-2xl font-bold tabular-nums text-gray-900">{{ $item['value'] }}</p>
                </div>
            @endif
        @endforeach
    </div>
</div>
