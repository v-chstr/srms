{{--
    Alpine-driven paper detail panel — card-style redesign.

    Expects an Alpine 'paper' variable in parent scope with keys:
    id, title, abstract, status, created_at, updated_at,
    submitter (nullable), course (nullable), adviser (nullable),
    authors (array), reviews (array with reviewer sub-objects)

    Props (Blade):
      - downloadUrlBase: string prefix, e.g. '/admin/papers'
      - showSubmitter: bool (default true) — hide for student's own papers
--}}
@props([
    'downloadUrlBase',
    'showSubmitter' => true,
])

@php
    $statusMapJson = collect(config('ui.statuses'))->map(fn ($s) => [
        'label' => $s['label_long'],
        'bg'    => $s['bg'],
        'text'  => $s['text'],
    ]);
@endphp

{{-- ── Status badge header (minimal) ────────────────────────── --}}
<div class="px-6 pt-4 pb-2">
    <span class="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-md"
          :class="(@js($statusMapJson)[paper.status] || { bg: 'bg-gray-100', text: 'text-gray-700' }).bg + ' ' + (@js($statusMapJson)[paper.status] || { text: 'text-gray-700' }).text"
          x-text="(@js($statusMapJson)[paper.status] || { label: paper.status.charAt(0).toUpperCase() + paper.status.slice(1) }).label"></span>
</div>

{{-- ── Metadata grid ────────────────────────────────────────── --}}
<div class="px-6 py-3 border-b border-gray-100">
    <div class="grid grid-cols-2 gap-x-8 gap-y-3 text-sm">

        @if($showSubmitter)
        <div class="min-w-0">
            <p class="text-xs font-semibold text-gray-400 mb-0.5">Submitted By</p>
            <p class="text-gray-900 break-all"
               x-text="paper.submitter ? paper.submitter.first_name + ' ' + paper.submitter.last_name : 'N/A'"></p>
        </div>
        @endif

        <div class="min-w-0">
            <p class="text-xs font-semibold text-gray-400 mb-0.5">Adviser</p>
            <template x-if="paper.adviser">
                <p class="text-gray-900 break-all"
                   x-text="paper.adviser.first_name + ' ' + paper.adviser.last_name"></p>
            </template>
            <template x-if="!paper.adviser && paper.adviser_name">
                <p class="text-gray-900 break-all" x-text="paper.adviser_name"></p>
            </template>
            <template x-if="!paper.adviser && !paper.adviser_name">
                <p class="text-gray-400">{{ config('ui.fallbacks.not_assigned') }}</p>
            </template>
        </div>

        <div class="min-w-0">
            <p class="text-xs font-semibold text-gray-400 mb-0.5">Submitted</p>
            <p class="text-gray-700 tabular-nums" x-text="paper.created_at"></p>
        </div>

        <div class="min-w-0">
            <p class="text-xs font-semibold text-gray-400 mb-0.5">Last Updated</p>
            <p class="text-gray-700 tabular-nums" x-text="paper.updated_at"></p>
        </div>

    </div>
</div>

{{-- ── Abstract ─────────────────────────────────────────────── --}}
<div class="px-6 py-3 border-b border-gray-100">
    <p class="text-xs font-semibold text-gray-400 mb-1.5">Abstract</p>
    <template x-if="paper.abstract">
        <p class="text-sm text-gray-700 whitespace-pre-line leading-relaxed break-all" x-text="paper.abstract"></p>
    </template>
    <template x-if="!paper.abstract">
        <p class="text-sm text-gray-400 italic">{{ config('ui.fallbacks.no_abstract') }}</p>
    </template>
</div>

{{-- ── Keywords ─────────────────────────────────────────────── --}}
<template x-if="paper.keywords && paper.keywords.length > 0">
    <div class="px-6 py-3 border-b border-gray-100">
        <p class="text-xs font-semibold text-gray-400 mb-1.5">Keywords</p>
        <div class="flex flex-wrap gap-1.5">
            <template x-for="kw in paper.keywords.slice(0, 6)" :key="kw">
                <span class="inline-block bg-gray-100 text-gray-600 text-xs px-2 py-0.5 rounded-md" x-text="kw"></span>
            </template>
            <template x-if="paper.keywords.length > 6">
                <span class="inline-block bg-gray-50 text-gray-400 text-xs px-2 py-0.5 rounded-md" x-text="'+' + (paper.keywords.length - 6) + ' more'"></span>
            </template>
        </div>
    </div>
</template>

{{-- ── Authors ──────────────────────────────────────────────── --}}
<template x-if="paper.authors && paper.authors.length > 0">
    <div class="px-6 py-3 border-b border-gray-100">
        <p class="text-xs font-semibold text-gray-400 mb-1.5">Authors</p>
        <ul class="space-y-0.5 text-sm text-gray-700">
            <template x-for="author in paper.authors" :key="author.first_name + author.last_name">
                <li x-text="author.first_name + ' ' + author.last_name"></li>
            </template>
        </ul>
    </div>
</template>

{{-- ── Review history ───────────────────────────────────────── --}}
<template x-if="paper.reviews && paper.reviews.length > 0">
    <div class="px-6 py-3 border-b border-gray-100">
        <p class="text-xs font-semibold text-gray-400 mb-2">Reviews</p>
        <div class="space-y-2">
            <template x-for="review in paper.reviews" :key="review.created_at">
                <div class="border border-gray-100 bg-gray-50 rounded-md p-3">
                    <div class="flex items-start justify-between gap-2 mb-1.5">
                        <span class="text-sm font-medium text-gray-900 min-w-0 break-all"
                              x-text="review.reviewer ? review.reviewer.first_name + ' ' + review.reviewer.last_name : 'Unknown'"></span>
                        <div class="flex items-center gap-2 shrink-0">
                            <span class="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-md"
                                  :class="review.decision === 'approved' ? 'bg-status-approved text-status-approved-fg' : 'bg-status-revision text-status-revision-fg'"
                                  x-text="review.decision === 'approved' ? '{{ config('ui.review_decisions.approved') }}' : '{{ config('ui.review_decisions.revision_required') }}'"></span>
                            <span class="text-xs text-gray-400 tabular-nums" x-text="review.created_at"></span>
                        </div>
                    </div>
                    <p class="text-sm text-gray-700 whitespace-pre-line break-all" x-text="review.comments"></p>
                </div>
            </template>
        </div>
    </div>
</template>

{{-- ── Download ──────────────────────────────────────────────── --}}
<div class="px-6 py-4">
    <a :href="'{{ $downloadUrlBase }}/' + paper.id + '/download'"
       class="inline-flex items-center gap-1.5 border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-1">
        Download PDF
    </a>
</div>
