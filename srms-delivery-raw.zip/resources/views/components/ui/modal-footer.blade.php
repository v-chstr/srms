@props([
    'modalName',
    'submitLabel' => 'Save',
    'submitVariant' => 'primary',
])

<div class="px-6 pb-5 pt-4 flex justify-end gap-3">
    <x-ui.button type="button" variant="secondary" x-on:click="$dispatch('close-modal', '{{ $modalName }}')">Cancel</x-ui.button>
    <x-ui.button type="submit" :variant="$submitVariant">{{ $submitLabel }}</x-ui.button>
</div>
