{{--
    Research submission form — rendered inside <x-ui.modal name="research-create">.
    Opened from the student research index page.

    Props:
      - advisers: Collection of adviser users
      - keywordSuggestions: array of suggested keywords
--}}
@props([
    'advisers',
    'keywordSuggestions' => [],
])

{{-- Header --}}
<div class="flex items-start justify-between border-b border-gray-200 px-5 py-4 shrink-0">
    <div class="min-w-0 pr-4">
        <h2 class="text-sm font-semibold text-gray-900">New Research Submission</h2>
        <p class="text-xs text-gray-500 mt-0.5">Upload your manuscript for adviser review</p>
    </div>
    <button type="button" x-on:click="$dispatch('close-modal', 'research-create')"
            class="shrink-0 mt-0.5 text-gray-400 hover:text-gray-600 transition-colors">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5">
            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
        </svg>
    </button>
</div>

<form method="POST" action="{{ route('student.research.store') }}" enctype="multipart/form-data"
      x-data="{ submitting: false }" @submit="submitting = true">
    @csrf
    <div class="px-5 pt-5 pb-0 space-y-4">
        <x-form.input name="title" label="Research Title" placeholder="Enter the full title of your research" :required="true" />

        <x-form.textarea name="abstract" label="Abstract" placeholder="Provide a summary of your research (max 1500 characters)" rows="4" :maxlength="1500" />

        <x-form.tag-input
            name="keywords"
            label="Keywords"
            placeholder="Type a keyword and press Enter"
            :max="10"
            :suggestions="$keywordSuggestions"
        />

        <x-form.author-input
            name="authors"
            label="Team Members"
            :submitter="auth()->user()"
            :required="true"
        />

        <x-form.select
            name="adviser_id"
            label="Research Adviser"
            :options="$advisers->mapWithKeys(fn ($a) => [$a->id => $a->last_name . ', ' . $a->first_name])->toArray()"
            placeholder="Select your adviser"
            :required="true"
        />

        <x-form.file
            name="manuscript"
            label="Manuscript (PDF)"
            hint="PDF only, maximum 20MB"
            :required="true"
        />
    </div>
    <div class="px-5 pb-5 pt-4 flex items-center justify-end gap-3 border-t border-gray-100 mt-5">
        <x-ui.button type="button" variant="secondary" x-on:click="$dispatch('close-modal', 'research-create')">Cancel</x-ui.button>
        <button type="submit" :disabled="submitting"
                :class="submitting ? 'opacity-50 cursor-not-allowed' : ''"
                class="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-colors">
            <template x-if="submitting">
                <svg class="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/></svg>
            </template>
            <span x-text="submitting ? 'Submitting...' : 'Submit Research'"></span>
        </button>
    </div>
</form>
