{{--
    Archive paper card — used in the archive grid.
    Props:
      - paper: ResearchPaper model with course + authors loaded
--}}
@props(['paper'])

<a href="{{ route('archive.show', $paper->id) }}" class="group flex flex-col rounded-lg border border-gray-200 bg-white overflow-hidden hover:border-primary-300 transition-colors">
    {{-- Box-shaped thumbnail (3:4 portrait, like a paper page) --}}
    <div class="relative aspect-[3/4] bg-gray-100 overflow-hidden border-b border-gray-200">
        @if($paper->thumbnail_path)
            <img src="{{ route('archive.thumbnail', $paper->id) }}"
                 alt="{{ $paper->title }}"
                 class="absolute inset-0 w-full h-full object-cover object-top"
                 loading="lazy" />
        @else
            <div class="absolute inset-0 flex flex-col items-center justify-center text-gray-300 bg-gradient-to-br from-gray-50 to-gray-100">
                <svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                </svg>
                <span class="mt-1 text-xs">PDF</span>
            </div>
        @endif

        {{-- Year badge overlay --}}
        <span class="absolute top-2 right-2 inline-block bg-white/90 backdrop-blur-sm text-gray-700 text-xs font-medium px-2 py-0.5 rounded-md tabular-nums">
            {{ $paper->published_year ?? $paper->created_at->year }}
        </span>
    </div>

    {{-- Card body --}}
    <div class="flex flex-col flex-1 px-3 py-2.5">
        @if($paper->course)
            <span class="text-xs font-medium text-primary-700 mb-1">{{ $paper->course->code ?? $paper->course->name }}</span>
        @endif
        <h3 class="text-sm font-semibold text-gray-900 leading-snug line-clamp-3 group-hover:text-primary-700">
            {{ $paper->title }}
        </h3>
        @if($paper->authors->isNotEmpty())
            <p class="mt-1.5 text-xs text-gray-500 line-clamp-1">
                {{ $paper->authors->map(fn ($a) => $a->last_name)->implode(', ') }}
            </p>
        @endif
    </div>
</a>
