@props(['title' => 'Dashboard'])

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title }} | SRMS</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen bg-gray-50 font-sans text-gray-900 antialiased" x-data="{ sidebarOpen: false, ...navManager() }" @click="handleNavClick($event)">

    {{-- Loading bar --}}
    <div x-show="navigating" x-cloak class="fixed top-0 left-0 right-0 z-[100] h-0.5 bg-primary-100">
        <div class="h-full bg-primary-500 animate-pulse" style="width: 90%;"></div>
    </div>

    {{-- Sidebar (desktop: fixed, mobile: slide-over) --}}
    <x-layouts.sidebar :unread-count="$unreadCount" />

    {{-- Main content area --}}
    <div class="lg:pl-56">
        {{-- Mobile top bar --}}
        <header class="sticky top-0 z-30 flex h-12 items-center gap-3 border-b border-gray-200 bg-white px-4 lg:hidden">
            <button @click="sidebarOpen = true" class="text-gray-500 hover:text-gray-700">
                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"/></svg>
            </button>
            <span class="text-[13px] font-semibold text-gray-800">{{ $title }}</span>

            @auth
            <button @click="$dispatch('open-modal', 'notifications')" class="relative ml-auto p-1.5 text-gray-500 hover:text-gray-700">
                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0"/></svg>
                @if($unreadCount > 0)
                    <span class="absolute -top-0.5 -right-0.5 flex h-3.5 min-w-[0.875rem] items-center justify-center rounded-full bg-red-500 px-0.5 text-[9px] font-bold text-white">{{ $unreadCount > 99 ? '99+' : $unreadCount }}</span>
                @endif
            </button>
            @endauth
        </header>

        {{-- Page content --}}
        <main class="px-4 py-5 sm:px-6 lg:px-8">
            @if(session('success'))
                <div class="mb-4"><x-ui.alert type="success">{{ session('success') }}</x-ui.alert></div>
            @endif
            @if(session('error'))
                <div class="mb-4"><x-ui.alert type="error">{{ session('error') }}</x-ui.alert></div>
            @endif

            {{ $slot }}
        </main>
    </div>

    {{-- Notifications modal --}}
    @auth
    <x-ui.modal name="notifications" maxWidth="md">
        {{-- Header --}}
        <div class="flex shrink-0 items-center justify-between border-b border-gray-200 px-5 py-4">
            <div class="flex items-center gap-2">
                <h2 class="text-sm font-semibold text-gray-900">Notifications</h2>
                @if($unreadCount > 0)
                    <span class="inline-flex items-center justify-center h-4 min-w-[1rem] px-1 rounded-full bg-red-500 text-[10px] font-bold text-white">{{ $unreadCount > 99 ? '99+' : $unreadCount }}</span>
                @endif
            </div>
            <div class="flex items-center gap-3">
                @if($unreadCount > 0)
                    <form method="POST" action="{{ route('notifications.read-all') }}">
                        @csrf
                        <button type="submit" class="text-[12px] font-medium text-primary-700 hover:text-primary-900">Mark all read</button>
                    </form>
                @endif
                @if($drawerNotifications->isNotEmpty())
                    <form method="POST" action="{{ route('notifications.clear-all') }}">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="text-[12px] font-medium text-red-600 hover:text-red-800">Clear all</button>
                    </form>
                @endif
                <button @click="$dispatch('close-modal', 'notifications')" class="p-1 text-gray-400 hover:text-gray-600 rounded-md">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>
        </div>

        {{-- Notification list --}}
        <div class="overflow-y-auto max-h-[60vh] divide-y divide-gray-100">
            @if($drawerNotifications->isEmpty())
                <p class="px-4 py-10 text-sm text-gray-400 text-center">No notifications yet.</p>
            @else
                @foreach($drawerNotifications as $notif)
                    @php
                        $isUnread = is_null($notif->read_at);
                        $notifData = $notif->data;
                        $notifType = $notifData['type'] ?? 'announcement';
                    @endphp
                    <div class="flex items-start gap-3 px-5 py-3 {{ $isUnread ? 'bg-primary-50' : '' }}">
                        <form method="POST" action="{{ route('notifications.read', $notif->id) }}" class="flex-1 min-w-0 flex items-start gap-3">
                            @csrf
                            @method('PATCH')
                            <button type="submit" class="flex-1 min-w-0 flex items-start gap-3 text-left hover:opacity-80">
                                <div class="shrink-0 mt-0.5 flex h-7 w-7 items-center justify-center rounded-full {{ $isUnread ? 'bg-primary-100' : 'bg-gray-100' }}">
                                    @if($notifType === 'research_submitted')
                                        <svg class="h-3.5 w-3.5 {{ $isUnread ? 'text-primary-600' : 'text-gray-500' }}" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m3.75 9v6m3-3H9m1.5-12H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"/></svg>
                                    @elseif($notifType === 'research_reviewed')
                                        <svg class="h-3.5 w-3.5 {{ $isUnread ? 'text-primary-600' : 'text-gray-500' }}" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                    @elseif($notifType === 'defense_scheduled')
                                        <svg class="h-3.5 w-3.5 {{ $isUnread ? 'text-primary-600' : 'text-gray-500' }}" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5"/></svg>
                                    @else
                                        <svg class="h-3.5 w-3.5 {{ $isUnread ? 'text-primary-600' : 'text-gray-500' }}" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10.34 15.84c-.688-.06-1.386-.09-2.09-.09H7.5a4.5 4.5 0 110-9h.75c.704 0 1.402-.03 2.09-.09m0 9.18c.253.962.584 1.892.985 2.783.247.55.06 1.21-.463 1.511l-.657.38c-.551.318-1.26.117-1.527-.461a20.845 20.845 0 01-1.44-4.282m3.102.069a18.03 18.03 0 01-.59-4.59c0-1.586.205-3.124.59-4.59m0 9.18a23.848 23.848 0 018.835 2.535M10.34 6.66a23.847 23.847 0 008.835-2.535m0 0A23.74 23.74 0 0018.795 3m.38 1.125a23.91 23.91 0 011.014 5.395m-1.014 8.855c-.118.38-.245.754-.38 1.125m.38-1.125a23.91 23.91 0 001.014-5.395m0-3.46c.495.413.811 1.035.811 1.73 0 .695-.316 1.317-.811 1.73m0-3.46a24.347 24.347 0 010 3.46"/></svg>
                                    @endif
                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="text-[13px] leading-snug {{ $isUnread ? 'font-medium text-gray-900' : 'text-gray-600' }}">
                                        {{ $notifData['message'] ?? $notifData['title'] ?? 'Notification' }}
                                    </p>
                                    <p class="text-xs text-gray-400 mt-0.5">{{ $notif->created_at->diffForHumans() }}</p>
                                </div>
                                @if($isUnread)
                                    <span class="shrink-0 mt-2 h-1.5 w-1.5 rounded-full bg-primary-500"></span>
                                @endif
                            </button>
                        </form>
                        <form method="POST" action="{{ route('notifications.destroy', $notif->id) }}" class="shrink-0 mt-1">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="p-1 text-gray-300 hover:text-red-500 rounded-md" title="Remove">
                                <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
                            </button>
                        </form>
                    </div>
                @endforeach
            @endif
        </div>
    </x-ui.modal>
    @endauth

    @stack('scripts')
</body>
</html>
