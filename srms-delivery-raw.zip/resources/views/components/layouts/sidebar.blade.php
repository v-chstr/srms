@props(['unreadCount' => 0])

@php
    $user = auth()->user();
    $role = $user?->role;
    $isAdmin = $role === 'admin';
    $canAdvise = $user?->canAdvise() ?? false;
@endphp

{{-- Mobile overlay --}}
<div x-show="sidebarOpen" x-cloak
     x-transition:enter="transition-opacity ease-out duration-200" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
     x-transition:leave="transition-opacity ease-in duration-150" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
     @click="sidebarOpen = false"
     class="fixed inset-0 z-40 bg-black/30 lg:hidden"></div>

<aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'"
       class="fixed inset-y-0 left-0 z-50 flex w-56 flex-col border-r border-gray-200 bg-white transition-transform duration-200 lg:translate-x-0">

    {{-- Brand --}}
    <div class="flex h-14 shrink-0 items-center border-b border-gray-100 px-4">
        <img src="{{ asset('images/spup-site.png') }}" alt="SITE" class="h-9 w-auto">
        <button @click="sidebarOpen = false" class="ml-auto lg:hidden text-gray-400 hover:text-gray-600">
            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
    </div>

    {{-- Nav links --}}
    <nav class="flex-1 overflow-y-auto px-3 py-3 space-y-0.5">
        <a href="{{ route('dashboard') }}" data-nav-link class="group flex items-center gap-3 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors {{ request()->routeIs('dashboard') ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900' }}">
            <span class="shrink-0 w-4 h-4 {{ request()->routeIs('dashboard') ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600' }}">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z"/></svg>
            </span>
            Dashboard
        </a>

        @if($isAdmin)
            <p class="px-2.5 pt-4 pb-1 text-xs font-medium text-gray-400">Admin</p>

            <a href="{{ route('admin.users.index') }}" data-nav-link class="group flex items-center gap-3 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors {{ request()->routeIs('admin.users.*') ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900' }}">
                <span class="shrink-0 w-4 h-4 {{ request()->routeIs('admin.users.*') ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600' }}">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z"/></svg>
                </span>
                Users
            </a>

            <a href="{{ route('admin.courses.index') }}" data-nav-link class="group flex items-center gap-3 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors {{ request()->routeIs('admin.courses.*') ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900' }}">
                <span class="shrink-0 w-4 h-4 {{ request()->routeIs('admin.courses.*') ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600' }}">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M4.26 10.147a60.436 60.436 0 00-.491 6.347A48.627 48.627 0 0112 20.904a48.627 48.627 0 018.232-4.41 60.46 60.46 0 00-.491-6.347m-15.482 0a50.57 50.57 0 00-2.658-.813A59.905 59.905 0 0112 3.493a59.902 59.902 0 0110.399 5.84c-.896.248-1.783.52-2.658.814m-15.482 0A50.697 50.697 0 0112 13.489a50.702 50.702 0 017.74-3.342"/></svg>
                </span>
                Courses
            </a>

            <a href="{{ route('admin.papers.index') }}" data-nav-link class="group flex items-center gap-3 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors {{ request()->routeIs('admin.papers.*') ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900' }}">
                <span class="shrink-0 w-4 h-4 {{ request()->routeIs('admin.papers.*') ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600' }}">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"/></svg>
                </span>
                Papers
            </a>

            <a href="{{ route('admin.announcements.index') }}" data-nav-link class="group flex items-center gap-3 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors {{ request()->routeIs('admin.announcements.*') ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900' }}">
                <span class="shrink-0 w-4 h-4 {{ request()->routeIs('admin.announcements.*') ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600' }}">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M10.34 15.84c-.688-.06-1.386-.09-2.09-.09H7.5a4.5 4.5 0 110-9h.75c.704 0 1.402-.03 2.09-.09m0 9.18c.253.962.584 1.892.985 2.783.247.55.06 1.21-.463 1.511l-.657.38c-.551.318-1.26.117-1.527-.461a20.845 20.845 0 01-1.44-4.282m3.102.069a18.03 18.03 0 01-.59-4.59c0-1.586.205-3.124.59-4.59m0 9.18a23.848 23.848 0 018.835 2.535M10.34 6.66a23.847 23.847 0 008.835-2.535m0 0A23.74 23.74 0 0018.795 3m.38 1.125a23.91 23.91 0 011.014 5.395m-1.014 8.855c-.118.38-.245.754-.38 1.125m.38-1.125a23.91 23.91 0 001.014-5.395m0-3.46c.495.413.811 1.035.811 1.73 0 .695-.316 1.317-.811 1.73m0-3.46a24.347 24.347 0 010 3.46"/></svg>
                </span>
                Announcements
            </a>

        @endif

        @if($canAdvise)
            <p class="px-2.5 pt-4 pb-1 text-xs font-medium text-gray-400">Adviser</p>

            <a href="{{ route('adviser.reviews.index') }}" data-nav-link class="group flex items-center gap-3 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors {{ request()->routeIs('adviser.reviews.*') ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900' }}">
                <span class="shrink-0 w-4 h-4 {{ request()->routeIs('adviser.reviews.*') ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600' }}">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15a2.25 2.25 0 012.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25z"/></svg>
                </span>
                Reviews
            </a>
        @endif

        @if($role === 'student')
            <p class="px-2.5 pt-4 pb-1 text-xs font-medium text-gray-400">Research</p>

            <a href="{{ route('student.research.index') }}" data-nav-link class="group flex items-center gap-3 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors {{ request()->routeIs('student.research.*') ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900' }}">
                <span class="shrink-0 w-4 h-4 {{ request()->routeIs('student.research.*') ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600' }}">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.331 0 4.512.645 6.374 1.766m0-13.724A8.966 8.966 0 0118 3.75c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25"/></svg>
                </span>
                My Research
            </a>

            <a href="{{ route('announcements.index') }}" data-nav-link class="group flex items-center gap-3 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors {{ request()->routeIs('announcements.*') ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900' }}">
                <span class="shrink-0 w-4 h-4 {{ request()->routeIs('announcements.*') ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600' }}">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M10.34 15.84c-.688-.06-1.386-.09-2.09-.09H7.5a4.5 4.5 0 110-9h.75c.704 0 1.402-.03 2.09-.09m0 9.18c.253.962.584 1.892.985 2.783.247.55.06 1.21-.463 1.511l-.657.38c-.551.318-1.26.117-1.527-.461a20.845 20.845 0 01-1.44-4.282m3.102.069a18.03 18.03 0 01-.59-4.59c0-1.586.205-3.124.59-4.59m0 9.18a23.848 23.848 0 018.835 2.535M10.34 6.66a23.847 23.847 0 008.835-2.535m0 0A23.74 23.74 0 0018.795 3m.38 1.125a23.91 23.91 0 011.014 5.395m-1.014 8.855c-.118.38-.245.754-.38 1.125m.38-1.125a23.91 23.91 0 001.014-5.395m0-3.46c.495.413.811 1.035.811 1.73 0 .695-.316 1.317-.811 1.73m0-3.46a24.347 24.347 0 010 3.46"/></svg>
                </span>
                Announcements
            </a>
        @endif

        @if($canAdvise && !$isAdmin)
            <div class="pt-3 mt-3 border-t border-gray-100 space-y-0.5">
                <a href="{{ route('adviser.announcements.index') }}" data-nav-link class="group flex items-center gap-3 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors {{ request()->routeIs('adviser.announcements.*') ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900' }}">
                    <span class="shrink-0 w-4 h-4 {{ request()->routeIs('adviser.announcements.*') ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600' }}">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 01-2.25 2.25M16.5 7.5V18a2.25 2.25 0 002.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 002.25 2.25h13.5"/></svg>
                    </span>
                    Announcements
                </a>
            </div>
        @endif

        <div class="{{ ($isAdmin || $canAdvise) ? '' : 'pt-3 mt-3 border-t border-gray-100' }} space-y-0.5">
            <a href="{{ route('archive.index') }}" data-nav-link class="group flex items-center gap-3 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors {{ request()->routeIs('archive.*') ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900' }}">
                <span class="shrink-0 w-4 h-4 {{ request()->routeIs('archive.*') ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600' }}">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z"/></svg>
                </span>
                Archive
            </a>
        </div>
    </nav>

    {{-- Profile footer --}}
    @auth
    <div class="shrink-0 border-t border-gray-100 p-3" x-data="{ open: false }">
        <div class="flex items-center gap-1">
            <button @click="open = !open" @click.outside="open = false" class="flex flex-1 min-w-0 items-center gap-2.5 rounded-md px-2.5 py-2 hover:bg-gray-50 transition-colors">
                <div class="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary-50 text-xs font-semibold text-primary-700">
                    {{ strtoupper(substr($user->first_name, 0, 1)) }}{{ strtoupper(substr($user->last_name, 0, 1)) }}
                </div>
                <div class="flex-1 min-w-0 text-left">
                    <p class="text-[13px] font-medium text-gray-900 truncate">{{ $user->first_name }} {{ $user->last_name }}</p>
                    <p class="text-xs text-gray-400 truncate">{{ ucfirst($user->role) }}</p>
                </div>
                <svg class="h-3.5 w-3.5 shrink-0 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"/></svg>
            </button>
            <button @click="$dispatch('open-modal', 'notifications')" class="relative shrink-0 p-2 rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-50 transition-colors">
                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0"/></svg>
                @if($unreadCount > 0)
                    <span class="absolute -top-0.5 -right-0.5 flex h-3.5 min-w-[0.875rem] items-center justify-center rounded-full bg-red-500 px-0.5 text-[9px] font-bold text-white">{{ $unreadCount > 99 ? '99+' : $unreadCount }}</span>
                @endif
            </button>
        </div>

        <div x-show="open" x-cloak
             x-transition:enter="transition ease-out duration-100" x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100"
             x-transition:leave="transition ease-in duration-75" x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-95"
             class="absolute bottom-16 left-3 right-3 rounded-md border border-gray-200 bg-white py-1 shadow-lg z-10">
            <div class="px-3 py-2 border-b border-gray-100">
                <p class="text-[13px] font-medium text-gray-900 truncate">{{ $user->first_name }} {{ $user->last_name }}</p>
                <p class="text-xs text-gray-500 truncate">{{ $user->email }}</p>
            </div>
            <a href="{{ route('profile.edit') }}" data-nav-link class="block px-3 py-1.5 text-[13px] text-gray-700 hover:bg-gray-50">Profile Settings</a>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="w-full text-left px-3 py-1.5 text-[13px] text-gray-700 hover:bg-gray-50">Sign out</button>
            </form>
        </div>
    </div>
    @else
    <div class="shrink-0 border-t border-gray-100 p-3">
        <a href="{{ route('login') }}" data-nav-link class="flex items-center justify-center gap-2 rounded-md px-2.5 py-2 text-[13px] font-medium text-primary-700 hover:bg-primary-50 transition-colors">
            Sign in
        </a>
    </div>
    @endauth
</aside>
