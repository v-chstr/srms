@props([
    'title',
    'subtitle' => null,
])

<div {{ $attributes->merge(['class' => 'mb-5 flex items-center justify-between']) }}>
    <div>
        <h1 class="text-lg font-semibold text-gray-900">{{ $title }}</h1>
        @if($subtitle)
            <p class="mt-0.5 text-[13px] text-gray-500">{{ $subtitle }}</p>
        @endif
    </div>
    @isset($actions)
        <div class="flex items-center gap-2 shrink-0">
            {{ $actions }}
        </div>
    @endisset
</div>
