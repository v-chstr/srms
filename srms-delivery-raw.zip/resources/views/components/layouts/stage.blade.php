@props(['title' => 'Research Archive'])

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title }} | SRMS</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen bg-gray-50 font-sans text-gray-900 antialiased">

    {{-- Masthead --}}
    <header class="sticky top-0 z-40 border-b border-gray-200 bg-white">
        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div class="flex h-14 items-center justify-between">
                {{-- Brand --}}
                <a href="{{ route('archive.index') }}" class="flex items-center">
                    <img src="{{ asset('images/spup-site.png') }}" alt="SITE" class="h-9 w-auto">
                </a>

                {{-- Right side --}}
                <div class="flex items-center gap-3">
                    @auth
                        <a href="{{ route('dashboard') }}" class="text-xs font-medium text-gray-500 hover:text-gray-900">Dashboard</a>
                    @else
                        <a href="{{ route('login') }}" class="text-xs font-medium text-gray-500 hover:text-gray-900">Sign in</a>
                    @endauth
                </div>
            </div>
        </div>
    </header>

    {{-- Page content --}}
    <main>
        {{ $slot }}
    </main>

    @stack('scripts')
</body>
</html>
