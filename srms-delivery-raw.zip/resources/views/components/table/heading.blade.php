@props([
    'sortable' => false,
])

<th {{ $attributes->merge(['class' => 'px-4 py-3 first:pl-5 last:pr-5 text-left text-xs font-semibold text-gray-600']) }}>
    {{ $slot }}
</th>
