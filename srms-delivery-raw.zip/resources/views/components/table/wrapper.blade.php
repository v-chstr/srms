@props(['paginator' => null])

<div {{ $attributes->merge(['class' => 'overflow-x-auto border border-gray-200 rounded-lg']) }}>
    <table class="min-w-full table-fixed divide-y divide-gray-200">
        @isset($head)
            <thead>
                <tr>{{ $head }}</tr>
            </thead>
        @endisset
        <tbody class="bg-white divide-y divide-gray-200">
            {{ $slot }}
        </tbody>
        @if($paginator && $paginator->hasPages())
            <tfoot>
                <tr>
                    <td colspan="100" class="px-3 py-2 bg-gray-50 border-t border-gray-200">
                        <x-ui.pagination :paginator="$paginator" />
                    </td>
                </tr>
            </tfoot>
        @endif
    </table>
</div>
