@props(['truncate' => false])

<td {{ $attributes->merge(['class' => 'px-4 py-3 first:pl-5 last:pr-5 text-sm text-gray-700']) }}>
    @if($truncate)
        <span class="block truncate">{{ $slot }}</span>
    @else
        {{ $slot }}
    @endif
</td>
