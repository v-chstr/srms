<x-layouts.app title="Profile Settings">

    <x-layouts.page-header title="Profile Settings" subtitle="Manage your personal information and account" />

    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

        {{-- ── LEFT COLUMN ─────────────────────────────────────── --}}
        <div class="lg:col-span-2 space-y-6">

            {{-- Account overview --}}
            <x-ui.card title="Account Overview">
                <div class="divide-y divide-gray-50">
                    <x-ui.detail-field label="Role">
                        @if($user->isAdmin() && $user->is_adviser)
                            <span class="text-sm font-medium text-gray-900">Admin / Research Adviser</span>
                        @else
                            <x-ui.badge :status="$user->role" />
                        @endif
                    </x-ui.detail-field>

                    @if(!($user->isAdmin() && $user->is_adviser))
                        <x-ui.detail-field label="Status">
                            <x-ui.badge :status="$user->status" />
                        </x-ui.detail-field>
                    @endif

                    @if($user->course)
                        <x-ui.detail-field label="Course">
                            <p class="text-sm font-medium text-gray-900">{{ $user->course->code }} — {{ $user->course->name }}</p>
                        </x-ui.detail-field>
                    @endif

                    <x-ui.detail-field label="Member since">
                        <p class="text-sm text-gray-700"><x-ui.date :value="$user->created_at" /></p>
                    </x-ui.detail-field>
                </div>
            </x-ui.card>

            {{-- Personal information --}}
            <x-ui.card title="Personal Information">
                <form method="POST" action="{{ route('profile.update') }}" class="space-y-5">
                    @csrf
                    @method('PATCH')

                    <div class="grid grid-cols-2 gap-4">
                        <x-form.input
                            name="first_name"
                            label="First name"
                            :value="$user->first_name"
                            :required="true"
                            maxlength="25"
                            pattern="[A-Za-z\s]+"
                            title="Letters and spaces only"
                        />
                        <x-form.input
                            name="last_name"
                            label="Last name"
                            :value="$user->last_name"
                            :required="true"
                            maxlength="25"
                            pattern="[A-Za-z\s]+"
                            title="Letters and spaces only"
                        />
                    </div>

                    <x-form.input
                        name="email"
                        type="email"
                        label="Email address"
                        :value="$user->email"
                        :required="true"
                        maxlength="255"
                    />

                    <div class="flex items-center gap-3">
                        <x-ui.button type="submit">Save Changes</x-ui.button>

                        @if(session('status') === 'profile-updated')
                            <p class="text-sm text-emerald-600">Saved.</p>
                        @endif
                    </div>
                </form>
            </x-ui.card>

            {{-- Delete account --}}
            <x-ui.card title="Delete Account">
                <p class="text-sm text-gray-600 mb-4">
                    Once your account is deleted, all of its data will be permanently removed. Please be certain.
                </p>
                <x-ui.button
                    variant="danger"
                    size="sm"
                    x-data=""
                    @click="$dispatch('open-modal', 'confirm-delete-account')"
                >
                    Delete Account
                </x-ui.button>
            </x-ui.card>

        </div>

        {{-- ── RIGHT COLUMN ────────────────────────────────────── --}}
        <div class="lg:col-span-1">
            <x-ui.card title="Change Password">
                <form method="POST" action="{{ route('profile.password') }}" class="space-y-5">
                    @csrf
                    @method('PATCH')

                    @foreach(['current_password' => 'Current password', 'password' => 'New password', 'password_confirmation' => 'Confirm new password'] as $fieldName => $fieldLabel)
                    <div class="space-y-1" x-data="{ show: false }">
                        <label for="{{ $fieldName }}" class="block text-sm font-medium text-gray-700">{{ $fieldLabel }} *</label>
                        <div class="relative">
                            <input
                                id="{{ $fieldName }}"
                                name="{{ $fieldName }}"
                                :type="show ? 'text' : 'password'"
                                required
                                class="block w-full border border-gray-300 px-3 py-2 pr-9 text-sm rounded-md shadow-sm focus:border-primary-500 focus:ring-primary-500 focus:outline-none"
                            />
                            <button type="button" @click="show = !show"
                                    class="absolute inset-y-0 right-0 flex items-center px-2.5 text-gray-400 hover:text-gray-600">
                                <svg x-show="!show" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                </svg>
                                <svg x-show="show" x-cloak class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88"/>
                                </svg>
                            </button>
                        </div>
                        <x-form.error :name="$fieldName" />
                    </div>
                    @endforeach

                    <div class="flex items-center gap-3">
                        <x-ui.button type="submit">Update Password</x-ui.button>

                        @if(session('status') === 'password-updated')
                            <p class="text-sm text-emerald-600">Updated.</p>
                        @endif
                    </div>
                </form>
            </x-ui.card>
        </div>

    </div>

    {{-- Delete confirmation modal --}}
    <x-ui.modal name="confirm-delete-account" title="Delete Account">
        <form method="POST" action="{{ route('profile.destroy') }}" class="space-y-4">
            @csrf
            @method('DELETE')

            <p class="text-sm text-gray-700">
                Enter your password to confirm you want to permanently delete your account.
            </p>

            <x-form.input
                name="password"
                type="password"
                label="Password"
                :required="true"
            />

            <div class="flex justify-end gap-3">
                <x-ui.button variant="secondary" type="button" @click="$dispatch('close-modal', 'confirm-delete-account')">
                    Cancel
                </x-ui.button>
                <x-ui.button variant="danger" type="submit">
                    Delete Account
                </x-ui.button>
            </div>
        </form>
    </x-ui.modal>

</x-layouts.app>
