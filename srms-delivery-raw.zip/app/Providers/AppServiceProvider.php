<?php

namespace App\Providers;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Schema::defaultStringLength(191);

        // SRMS date formatting macros — single source of truth for all date displays.
        // Standard format: Apr 12, 2026 2:30 PM (academic readable).
        // Use these in @php blocks instead of hardcoding format strings.
        // In Blade output, use <x-ui.date> instead.
        Carbon::macro('srmsDate',     fn () => $this->format('M j, Y g:i A'));    // Apr 12, 2026 2:30 PM
        Carbon::macro('srmsDateTime', fn () => $this->format('M j, Y g:i A'));    // Apr 12, 2026 2:30 PM (same as srmsDate)
        Carbon::macro('srmsShort',    fn () => $this->format('M j, Y'));          // Apr 12, 2026
        Carbon::macro('srmsNumeric',  fn () => $this->format('M j, Y g:i A'));    // Apr 12, 2026 2:30 PM (always with time)
        Carbon::macro('srmsTime',     fn () => $this->format('g:i A'));           // 2:30 PM

        // Provide $unreadCount and $drawerNotifications to the app layout.
        // Provide $unreadCount and $drawerNotifications to the app layout on every page.
        View::composer('components.layouts.app', function ($view) {
            $unreadCount = 0;
            $drawerNotifications = collect();

            if (Auth::check()) {
                /** @var \App\Models\User $user */
                $user = Auth::user();
                $unreadCount = $user->unreadNotifications()->count();
                $drawerNotifications = $user->notifications()->latest()->limit(15)->get();
            }

            $view->with('unreadCount', $unreadCount);
            $view->with('drawerNotifications', $drawerNotifications);
        });
    }
}
