<?php

namespace App\Console\Commands;

use App\Models\ResearchPaper;
use App\Services\ResearchService;
use Illuminate\Console\Command;

class GenerateThumbnails extends Command
{
    protected $signature = 'papers:generate-thumbnails {--force : Regenerate all thumbnails, not just missing ones}';

    protected $description = 'Generate JPEG thumbnails for research papers that lack them (requires Imagick)';

    public function handle(ResearchService $researchService): int
    {
        if (! extension_loaded('imagick')) {
            $this->error('Imagick PHP extension is not installed. Thumbnails cannot be generated.');
            return self::FAILURE;
        }

        $query = ResearchPaper::query();

        if (! $this->option('force')) {
            $query->whereNull('thumbnail_path');
        }

        $papers = $query->get();

        if ($papers->isEmpty()) {
            $this->info('No papers need thumbnail generation.');
            return self::SUCCESS;
        }

        $this->info("Generating thumbnails for {$papers->count()} papers...");

        $bar = $this->output->createProgressBar($papers->count());
        $bar->start();

        $success = 0;
        $failed = 0;

        foreach ($papers as $paper) {
            $thumbnailPath = $researchService->generateThumbnail($paper->file_path);

            if ($thumbnailPath) {
                $paper->update(['thumbnail_path' => $thumbnailPath]);
                $success++;
            } else {
                $failed++;
            }

            $bar->advance();
        }

        $bar->finish();
        $this->newLine(2);

        $this->info("Done. {$success} thumbnails generated, {$failed} failed.");

        return self::SUCCESS;
    }
}
