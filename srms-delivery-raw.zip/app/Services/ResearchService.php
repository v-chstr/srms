<?php

namespace App\Services;

use App\Models\ResearchAuthor;
use App\Models\ResearchPaper;
use App\Models\Review;
use App\Models\User;
use App\Notifications\ResearchReviewed;
use App\Notifications\ResearchSubmitted;
use Illuminate\Filesystem\FilesystemAdapter;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ResearchService
{
    /**
     * Store a new research paper submission.
     * Saves the manuscript file to the configured disk and creates the DB record.
     */
    public function store(array $validated, User $submitter): ResearchPaper
    {
        abort_if(
            is_null($submitter->course_id),
            422,
            'Your account has no course assigned. Please contact an administrator.'
        );

        $disk = config('filesystems.default');
        $originalFilename = $validated['manuscript']->getClientOriginalName();
        $path = $validated['manuscript']->store('research/manuscripts', $disk);

        $thumbnailPath = $this->generateThumbnail($path, $disk);

        $paper = ResearchPaper::create([
            'title'             => $validated['title'],
            'abstract'          => $validated['abstract'] ?? null,
            'keywords'          => $validated['keywords'] ?? null,
            'file_path'         => $path,
            'original_filename' => $originalFilename,
            'thumbnail_path'    => $thumbnailPath,
            'course_id'         => $submitter->course_id,
            'submitted_by'      => $submitter->id,
            'adviser_id'        => $validated['adviser_id'] ?? null,
            'status'            => 'pending',
        ]);

        // Save authors from form input.
        $this->syncAuthors($paper, $validated['authors'] ?? [], $submitter);

        // Notify the assigned adviser.
        $this->notifyAdviser($paper, isResubmission: false);

        return $paper;
    }

    /**
     * Update an existing paper (resubmission after revision).
     * Replaces the file on disk if a new manuscript is provided.
     */
    public function update(array $validated, ResearchPaper $paper): ResearchPaper
    {
        $disk = config('filesystems.default');

        $originalFilename = null;

        if (isset($validated['manuscript'])) {
            // Delete the old file before storing the replacement.
            /** @var FilesystemAdapter $storage */
            $storage = Storage::disk($disk);
            $storage->delete($paper->file_path);
            if ($paper->thumbnail_path) {
                $storage->delete($paper->thumbnail_path);
            }
            $originalFilename = $validated['manuscript']->getClientOriginalName();
            $validated['file_path'] = $validated['manuscript']->store('research/manuscripts', $disk);
        }

        $newFilePath = $validated['file_path'] ?? $paper->file_path;

        // Regenerate thumbnail if the manuscript changed.
        $thumbnailPath = isset($validated['manuscript'])
            ? $this->generateThumbnail($newFilePath, $disk)
            : $paper->thumbnail_path;

        $updateData = [
            'title'          => $validated['title'],
            'abstract'       => $validated['abstract'] ?? null,
            'keywords'       => $validated['keywords'] ?? null,
            'file_path'      => $newFilePath,
            'thumbnail_path' => $thumbnailPath,
            'adviser_id'     => $validated['adviser_id'] ?? $paper->adviser_id,
            'status'         => 'pending',
        ];

        if ($originalFilename) {
            $updateData['original_filename'] = $originalFilename;
        }

        $paper->update($updateData);

        // Re-sync authors from form input.
        $this->syncAuthors($paper, $validated['authors'] ?? [], $paper->submitter);

        $paper = $paper->fresh();

        // Notify the assigned adviser of the resubmission.
        $this->notifyAdviser($paper, isResubmission: true);

        return $paper;
    }

    /**
     * Record an adviser's review and transition the paper's status.
     */
    public function submitReview(ResearchPaper $paper, array $validated, User $reviewer): Review
    {
        $review = Review::create([
            'research_paper_id' => $paper->id,
            'reviewer_id'       => $reviewer->id,
            'comments'          => $validated['comments'],
            'decision'          => $validated['decision'],
        ]);

        $isApproved = $validated['decision'] === 'approved';

        $paper->update([
            'status'         => $isApproved ? 'approved' : 'revision',
            'published_year' => $isApproved ? now()->year : $paper->published_year,
        ]);

        // Notify the student who submitted the paper
        $paper->load('submitter');
        $paper->submitter->notify(new ResearchReviewed($paper, $review));

        return $review;
    }

    /**
     * Serve a secure file download, respecting the active disk.
     *
     * R2 uses a 30-minute presigned temporary URL (S3-compatible GET).
     * Local disk streams the file directly through the Laravel response.
     */
    public function download(ResearchPaper $paper): StreamedResponse
    {
        $diskName = config('filesystems.default');

        /** @var FilesystemAdapter $disk */
        $disk = Storage::disk($diskName);

        // Stream the file directly through the app — no time-limited presigned URLs.
        // This ensures the download is always available and access is controlled by middleware.
        return $disk->download(
            $paper->file_path,
            $paper->original_filename ?? $paper->title . '.pdf'
        );
    }

    /**
     * Notify the assigned adviser (if any) that a paper was submitted or resubmitted.
     */
    private function notifyAdviser(ResearchPaper $paper, bool $isResubmission): void
    {
        if (! $paper->adviser_id) {
            return;
        }

        $paper->loadMissing(['submitter', 'adviser']);
        $paper->adviser->notify(new ResearchSubmitted($paper, $isResubmission));
    }

    /**
     * Admin direct upload — store an old/existing paper as approved.
     * No notifications sent, no student submitter required.
     */
    public function storeDirectUpload(array $validated, User $admin): ResearchPaper
    {
        $disk = config('filesystems.default');
        $originalFilename = $validated['manuscript']->getClientOriginalName();
        $path = $validated['manuscript']->store('research/manuscripts', $disk);

        $thumbnailPath = $this->generateThumbnail($path, $disk);

        $paper = ResearchPaper::create([
            'title'             => $validated['title'],
            'abstract'          => $validated['abstract'] ?? null,
            'keywords'          => $validated['keywords'] ?? null,
            'file_path'         => $path,
            'original_filename' => $originalFilename,
            'thumbnail_path'    => $thumbnailPath,
            'course_id'         => $validated['course_id'],
            'submitted_by'      => $admin->id,
            'adviser_id'        => $validated['adviser_id'] ?? null,
            'status'            => 'approved',
            'published_year'    => $validated['published_year'],
        ]);

        // Save authors from form input — no submitter guarantee needed.
        foreach ($validated['authors'] ?? [] as $index => $authorData) {
            ResearchAuthor::create([
                'research_paper_id' => $paper->id,
                'first_name'        => $authorData['first_name'],
                'last_name'         => $authorData['last_name'],
                'is_submitter'      => false,
                'sort_order'        => $index,
            ]);
        }

        return $paper;
    }

    /**
     * Generate a JPEG thumbnail from the first page of a PDF.
     * Requires the Imagick PHP extension. Returns null if unavailable.
     */
    public function generateThumbnail(string $pdfPath, ?string $diskName = null): ?string
    {
        if (! extension_loaded('imagick')) {
            return null;
        }

        $diskName = $diskName ?? config('filesystems.default');

        /** @var FilesystemAdapter $disk */
        $disk = Storage::disk($diskName);

        try {
            $pdfContent = $disk->get($pdfPath);

            /** @var \Imagick $imagick */
            $imagick = new \Imagick();
            $imagick->setResolution(150, 150);
            $imagick->readImageBlob($pdfContent);
            $imagick->setIteratorIndex(0);
            $imagick->setImageFormat('jpeg');
            $imagick->setImageCompressionQuality(80);
            $imagick->thumbnailImage(400, 0);

            $thumbnailPath = 'research/thumbnails/' . pathinfo($pdfPath, PATHINFO_FILENAME) . '.jpg';
            $disk->put($thumbnailPath, $imagick->getImageBlob());

            $imagick->clear();
            $imagick->destroy();

            return $thumbnailPath;
        } catch (\Exception $e) {
            report($e);
            return null;
        }
    }

    /**
     * Serve a paper's thumbnail image from disk.
     * Returns null if no thumbnail exists.
     */
    public function serveThumbnail(ResearchPaper $paper): ?\Symfony\Component\HttpFoundation\Response
    {
        if (! $paper->thumbnail_path) {
            return null;
        }

        $diskName = config('filesystems.default');

        /** @var FilesystemAdapter $disk */
        $disk = Storage::disk($diskName);

        if (! $disk->exists($paper->thumbnail_path)) {
            return null;
        }

        $mimeType = $disk->mimeType($paper->thumbnail_path) ?: 'image/jpeg';

        return response($disk->get($paper->thumbnail_path), 200, [
            'Content-Type'  => $mimeType,
            'Cache-Control' => 'public, max-age=86400',
        ]);
    }

    /**
     * Replace all authors for a paper with the provided array.
     * Ensures the submitter is always present as the first author.
     */
    private function syncAuthors(ResearchPaper $paper, array $authorsInput, User $submitter): void
    {
        $paper->authors()->delete();

        $hasSubmitter = false;

        foreach ($authorsInput as $index => $authorData) {
            $isSubmitter = (bool) ($authorData['is_submitter'] ?? false);
            if ($isSubmitter) {
                $hasSubmitter = true;
            }

            ResearchAuthor::create([
                'research_paper_id' => $paper->id,
                'first_name'        => $authorData['first_name'],
                'last_name'         => $authorData['last_name'],
                'is_submitter'      => $isSubmitter,
                'sort_order'        => $index,
            ]);
        }

        // Guarantee submitter is present even if form somehow omitted them.
        if (! $hasSubmitter) {
            ResearchAuthor::create([
                'research_paper_id' => $paper->id,
                'first_name'        => $submitter->first_name,
                'last_name'         => $submitter->last_name,
                'is_submitter'      => true,
                'sort_order'        => 0,
            ]);
        }
    }
}
