<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Course extends Model
{
    use HasFactory;

    protected $fillable = [
        'code',
        'name',
        'submission_start',
        'submission_end',
    ];

    protected function casts(): array
    {
        return [
            'submission_start' => 'datetime',
            'submission_end'   => 'datetime',
        ];
    }

    public function researchPapers(): HasMany
    {
        return $this->hasMany(ResearchPaper::class);
    }

    public function defenseSchedules(): HasMany
    {
        return $this->hasMany(DefenseSchedule::class);
    }

    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }
}
