<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use App\Models\Course;
use App\Models\DefenseSchedule;
use App\Models\ResearchPaper;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(Request $request): View
    {
        $user = $request->user();

        return match ($user->role) {
            'admin'   => $this->adminDashboard($user),
            'adviser' => $this->adviserDashboard($user),
            'student' => $this->studentDashboard($user),
            default   => abort(403, 'Unauthorized.'),
        };
    }

    private function adminDashboard(User $user): View
    {
        // Single query: all paper counts via conditional aggregation
        $paperAgg = ResearchPaper::query()
            ->selectRaw("COUNT(*) as total_papers")
            ->selectRaw("SUM(status = 'pending')  as pending_papers")
            ->selectRaw("SUM(status = 'revision') as revision_papers")
            ->selectRaw("SUM(status = 'approved') as approved_papers")
            ->first();

        // To add a new stat: add a row to $statItems below. No Blade changes needed.
        $statItems = [
            ['label' => 'Total Users',       'value' => User::where('status', 'active')->count(),  'color' => 'gray'],
            ['label' => 'Pending Requests',  'value' => User::where('status', 'pending')->count(), 'color' => 'gray'],
            ['group' => true, 'label' => 'Paper Track', 'items' => [
                ['label' => 'Total',    'value' => (int) $paperAgg->total_papers],
                ['label' => 'Pending',  'value' => (int) $paperAgg->pending_papers],
                ['label' => 'Revision', 'value' => (int) $paperAgg->revision_papers],
                ['label' => 'Approved', 'value' => (int) $paperAgg->approved_papers],
            ]],
        ];

        // If this admin is also an adviser, append their personal adviser stats after a divider.
        // To add more adviser stats (e.g. defenses): append rows inside this block only.
        if ($user->canAdvise()) {
            $myAgg = ResearchPaper::where('adviser_id', $user->id)
                ->selectRaw("COUNT(*) as assigned")
                ->selectRaw("SUM(status = 'pending')  as pending_reviews")
                ->selectRaw("SUM(status = 'revision') as revision_papers")
                ->selectRaw("SUM(status = 'approved') as approved_papers")
                ->first();

            $statItems[] = ['divider' => true];
            $statItems[] = ['group' => true, 'label' => 'My Advising', 'items' => [
                ['label' => 'Pending',  'value' => (int) $myAgg->pending_reviews],
                ['label' => 'Revision', 'value' => (int) $myAgg->revision_papers],
                ['label' => 'Approved', 'value' => (int) $myAgg->approved_papers],
            ]];
        }

        // Course research output breakdown
        $courseOutput = Course::withCount('researchPapers')
            ->orderByDesc('research_papers_count')
            ->get()
            ->map(fn ($c) => ['name' => $c->name, 'code' => $c->code, 'count' => $c->research_papers_count]);

        $recentPapers = ResearchPaper::with(['submitter', 'course'])
            ->latest()
            ->take(3)
            ->get();

        $pendingUsers = User::where('status', 'pending')
            ->with('course')
            ->latest()
            ->take(3)
            ->get();

        [$latestAnnouncement, $unseenAnnouncementCount] = $this->getAnnouncementData($user);

        [$scheduleEvents, $courses, $schedules] = $this->getScheduleData($user);

        return view('dashboard', [
            'role'                     => 'admin',
            'statItems'                => $statItems,
            'courseOutput'             => $courseOutput,
            'recentPapers'             => $recentPapers,
            'pendingUsers'             => $pendingUsers,
            'latestAnnouncement'       => $latestAnnouncement,
            'unseenAnnouncementCount'  => $unseenAnnouncementCount,
            'scheduleEvents'           => $scheduleEvents,
            'courses'                  => $courses,
            'schedules'                => $schedules,
        ]);
    }

    private function adviserDashboard(User $user): View
    {
        // Single query: all adviser paper counts via conditional aggregation
        $adviserAgg = ResearchPaper::where('adviser_id', $user->id)
            ->selectRaw("COUNT(*) as assigned_papers")
            ->selectRaw("SUM(status = 'pending')  as pending_reviews")
            ->selectRaw("SUM(status = 'revision') as revision_papers")
            ->first();

        // To add a new stat: add a row here. No Blade changes needed.
        $statItems = [
            ['label' => 'Assigned', 'value' => (int) $adviserAgg->assigned_papers, 'color' => 'gray'],
            ['group' => true, 'label' => 'Review Queue', 'items' => [
                ['label' => 'Pending',  'value' => (int) $adviserAgg->pending_reviews],
                ['label' => 'Revision', 'value' => (int) $adviserAgg->revision_papers],
                ['label' => 'Reviewed', 'value' => $user->reviews()->count()],
            ]],
        ];

        $recentPapers = ResearchPaper::with(['submitter', 'course'])
            ->where('adviser_id', $user->id)
            ->latest()
            ->take(3)
            ->get();

        [$latestAnnouncement, $unseenAnnouncementCount] = $this->getAnnouncementData($user);

        [$scheduleEvents, $courses, $schedules] = $this->getScheduleData($user);

        return view('dashboard', [
            'role'                     => 'adviser',
            'statItems'                => $statItems,
            'recentPapers'             => $recentPapers,
            'latestAnnouncement'       => $latestAnnouncement,
            'unseenAnnouncementCount'  => $unseenAnnouncementCount,
            'scheduleEvents'           => $scheduleEvents,
            'courses'                  => $courses,
            'schedules'                => $schedules,
        ]);
    }

    private function studentDashboard(User $user): View
    {
        // Single query: all student submission counts via conditional aggregation
        $studentAgg = ResearchPaper::where('submitted_by', $user->id)
            ->selectRaw("COUNT(*) as total_submissions")
            ->selectRaw("SUM(status = 'pending')  as pending_submissions")
            ->selectRaw("SUM(status = 'revision') as revision_submissions")
            ->selectRaw("SUM(status = 'approved') as approved_submissions")
            ->first();

        // To add a new stat: add a row here. No Blade changes needed.
        $statItems = [
            ['label' => 'Submissions', 'value' => (int) $studentAgg->total_submissions, 'color' => 'gray'],
            ['group' => true, 'label' => 'Status Breakdown', 'items' => [
                ['label' => 'Under Review', 'value' => (int) $studentAgg->pending_submissions],
                ['label' => 'For Revision', 'value' => (int) $studentAgg->revision_submissions],
                ['label' => 'Approved',     'value' => (int) $studentAgg->approved_submissions],
            ]],
        ];

        $recentPapers = ResearchPaper::with(['adviser', 'course'])
            ->where('submitted_by', $user->id)
            ->latest()
            ->take(3)
            ->get();

        [$latestAnnouncement, $unseenAnnouncementCount] = $this->getAnnouncementData($user);

        [$scheduleEvents, $courses] = $this->getScheduleData($user);

        return view('dashboard', [
            'role'                     => 'student',
            'statItems'                => $statItems,
            'recentPapers'             => $recentPapers,
            'latestAnnouncement'       => $latestAnnouncement,
            'unseenAnnouncementCount'  => $unseenAnnouncementCount,
            'scheduleEvents'           => $scheduleEvents,
            'courses'                  => $courses,
        ]);
    }

    /**
     * Get the latest announcement and unseen count for the given user.
     *
     * @return array{0: ?\App\Models\Announcement, 1: int}
     */
    private function getAnnouncementData(User $user): array
    {
        $baseQuery = Announcement::with(['poster', 'course'])->active();

        // Students only see global + their course announcements
        if ($user->isStudent()) {
            $baseQuery->where(function ($q) use ($user) {
                $q->whereNull('course_id')
                  ->orWhere('course_id', $user->course_id);
            });
        }

        $latestAnnouncement = (clone $baseQuery)->latest()->first();

        $lastReadAt = $user->last_announcement_read_at;

        if ($lastReadAt) {
            $totalUnseen = (clone $baseQuery)->where('created_at', '>', $lastReadAt)->count();
        } else {
            $totalUnseen = (clone $baseQuery)->count();
        }

        // Subtract the one already shown on dashboard
        $unseenAnnouncementCount = max($totalUnseen - ($latestAnnouncement ? 1 : 0), 0);

        return [$latestAnnouncement, $unseenAnnouncementCount];
    }

    /**
     * Get defense schedule events as a JSON-ready array + course list for the calendar.
     *
     * @return array{0: \Illuminate\Support\Collection, 1: \Illuminate\Database\Eloquent\Collection}
     */
    private function getScheduleData(User $user): array
    {
        $schedules = DefenseSchedule::with(['course', 'creator'])
            ->active()
            ->forUser($user)
            ->orderBy('scheduled_date')
            ->orderBy('start_time')
            ->get();

        $events = $schedules->map(fn (DefenseSchedule $s) => [
            'id'    => $s->id,
            'title' => $s->title,
            'start' => $s->scheduled_date->format('Y-m-d') . 'T' . $s->start_time->format('H:i:s'),
            'end'   => $s->end_time
                ? $s->scheduled_date->format('Y-m-d') . 'T' . $s->end_time->format('H:i:s')
                : null,
            'extendedProps' => [
                'schedule_id'    => $s->id,
                'description'    => $s->description,
                'room'           => $s->room,
                'course_code'    => $s->course?->code,
                'course_name'    => $s->course?->name,
                'is_global'      => $s->isGlobal(),
                'creator_name'   => $s->creator ? $s->creator->first_name . ' ' . $s->creator->last_name : 'Unknown',
                'start_time'     => $s->start_time->format('g:i A'),
                'end_time'       => $s->end_time?->format('g:i A'),
                'scheduled_date' => $s->scheduled_date->format('M d, Y'),
            ],
            'classNames' => $s->isGlobal() ? ['fc-event-global'] : ['fc-event-course'],
        ]);

        $courses = Course::orderBy('code')->get();

        return [$events, $courses, $schedules];
    }
}
