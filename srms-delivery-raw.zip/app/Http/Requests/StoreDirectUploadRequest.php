<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreDirectUploadRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->role === 'admin';
    }

    public function rules(): array
    {
        return [
            'title'                => ['required', 'string', 'max:255'],
            'abstract'             => ['nullable', 'string', 'max:1500'],
            'course_id'            => ['required', 'integer', 'exists:courses,id'],
            'adviser_id'           => ['nullable', 'integer', 'exists:users,id'],
            'published_year'       => ['required', 'integer'],
            'manuscript'           => ['required', 'file', 'mimes:pdf', 'max:20480'],
            'keywords'             => ['nullable', 'array', 'max:10'],
            'keywords.*'           => ['string', 'max:100'],
            'authors'              => ['required', 'array', 'min:1'],
            'authors.*.first_name' => ['required', 'string', 'max:191'],
            'authors.*.last_name'  => ['required', 'string', 'max:191'],
        ];
    }
}
